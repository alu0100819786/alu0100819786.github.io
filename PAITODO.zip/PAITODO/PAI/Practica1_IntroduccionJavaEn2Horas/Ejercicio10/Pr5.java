/*
Asignatura: Programación de Aplicaciones Interactivas
Tema:       Introducción a la Programación en Java
Autor/a:
e-mail:
Fecha:

Ponga aquí sus comentarios / solución

SOLUCIÓN / RESPUESTA:
*/

import java.util.ArrayList;

class Pr5 {
   public static void main (String args[]) {
      int k, n, dia, mes, año, size = args.length;
      ArrayList<Integer> a = new ArrayList<>();

      for (k = 0; k < size; ++k) {
         a.add( new Integer(args[k]) );
         n = a.get(k);
	 
         System.out.println( "a[" + k + "]= " + n );
      }
	dia = a.get(0);
	mes = a.get(1);
	año = a.get(2);
	System.out.println( "El dia es: " + dia);
	System.out.println( "El mes es: " + mes);
	System.out.println( "El año es: " + año);
   }
}
