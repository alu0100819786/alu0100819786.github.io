/*
Asignatura: Programación de Aplicaciones Interactivas
Tema:       Introducción a la Programación en Java
Autor/a:
e-mail:
Fecha:

Ponga aquí sus comentarios / solución

SOLUCIÓN / RESPUESTA:
*/

import java.util.*;

public class Ejercicio16 {
  public static void main(String[] args) {
    System.out.println("TreeSet con Pairs!\n");
    TreeSet <Integer>tree = new TreeSet<Integer>();
    tree.add(12);
    tree.add(23);
    tree.add(34);
    tree.add(45);
    Iterator iterator;
    iterator = tree.iterator();
    System.out.print("Tree set data: ");
    //Displaying the Tree set data
    while (iterator.hasNext()){
      System.out.print(iterator.next() + " ");
    }
    System.out.println();
    
		Pair p1 = new Pair(1, 2);
		Pair p2 = new Pair(3, 4);
		Pair p3 = new Pair(5, 6);
    TreeSet <Pair>arbol = new TreeSet<Pair>();
		arbol.add(p1);
		arbol.add(p2);
		arbol.add(p3);
  }
}
