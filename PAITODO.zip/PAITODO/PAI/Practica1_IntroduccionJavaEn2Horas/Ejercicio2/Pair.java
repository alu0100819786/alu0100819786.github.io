public class Pair{

int first, second;

}
