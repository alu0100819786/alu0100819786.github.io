public class Pair{

int first, second;


public String toString(){

String aux= '('+Integer.toString(first)+','+Integer.toString(second)+')'+'\n';

return aux;

}

public boolean equals(Pair p){

return (first == p.first & second == p.second);
}

}


