/*
Asignatura: Programación de Aplicaciones Interactivas
Tema:       Introducción a la Programación en Java
Autor/a: Gabriel Melián Hernández
e-mail: alu0100819786@ull.edu.es
Fecha: 08/02/17

Ponga aquí sus comentarios / solución

SOLUCIÓN / RESPUESTA:
*/

class Pr2 {
   public static void main (String[] args) {
      Pair p = new Pair();  
      System.out.print("El par es " + p);
   }
}
