/*
Asignatura: Programación de Aplicaciones Interactivas
Tema:       Introducción a la Programación en Java
Autor/a: Gabriel Melián Hernández
e-mail: alu0100819786@ull.edu.es
Fecha: 08/02/17

Ponga aquí sus comentarios / solución

SOLUCIÓN / RESPUESTA:
*/

class Pr3 {
   public static void main (String[] args) {
      Pair p = new Pair(4,7);
System.out.print("El par es " + p);
	Pair q = new Pair(3,2);  
      System.out.print("El par es " + q);
   }
}
