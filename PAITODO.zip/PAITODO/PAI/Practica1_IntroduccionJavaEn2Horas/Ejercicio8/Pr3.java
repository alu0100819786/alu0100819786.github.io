/*
Asignatura: Programación de Aplicaciones Interactivas
Tema:       Introducción a la Programación en Java
Autor/a: Gabriel Melián Hernández
e-mail: alu0100819786@ull.edu.es
Fecha: 08/02/17

Ponga aquí sus comentarios / solución

SOLUCIÓN / RESPUESTA:
*/

class Pr3 {
   public static void main (String[] args) {
      
Pair par1,par2;

par1 = new Pair(1,2);

par2=par1;

par2.reflex();

System.out.print(par1);
   }
}
