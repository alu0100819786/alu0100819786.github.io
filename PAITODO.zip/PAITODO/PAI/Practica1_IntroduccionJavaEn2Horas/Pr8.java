/*
Asignatura: Programación de Aplicaciones Interactivas
Tema:       Introducción a la Programación en Java
Autor/a:
e-mail:
Fecha:

Ponga aquí sus comentarios / solución

SOLUCIÓN / RESPUESTA:
*/


import java.util.*;

class Pr8 {
  public static void main (String args[]) {
    String data = "100 200 300" ;
    String [] token = data.split("\\s");

    for (int k = 0; k < token.length; ++k)
      System.out.println(token[k]);
  }
}
