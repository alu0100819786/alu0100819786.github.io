  public Pair(int first, int second) {
	  this.first = first;
	  this.second = second;
	}

  public void swap(Pair q) {
    Pair temp = q;
    q = this;
    this.first = temp.first;
    this.second = temp.second;
  }
