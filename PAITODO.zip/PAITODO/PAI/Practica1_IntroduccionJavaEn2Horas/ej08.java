  public void reflex () {
    int z = first; 
		first = second; 
		second = z;
  }
