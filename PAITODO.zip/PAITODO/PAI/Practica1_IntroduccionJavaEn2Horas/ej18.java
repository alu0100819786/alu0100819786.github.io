  public boolean equals (Object o) {
    if (o!= null && this.getClass() == o.getClass()) {
      Pair p = (Pair)o;
      return first == p.first && second == p.second;
    } else 
      return false;
  }

  public int hashCode() {
    return Integer.valueOf(first).hashCode() + 31 * Integer.valueOf(second).hashCode();
  }
