//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 3: Clase Fecha.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import static org.junit.Assert.*;
import java.io.*;
import java.util.Hashtable;
import java.util.Scanner;
import org.junit.Test;
//-----Implementacion de los test en JUnit para la clase ALexico.-----
public class PrincipalTest {
	@Test
	public void testMain() throws IOException{
		Hashtable<String,String> tablaSimbolos=new Hashtable<String,String>();
		FileReader tabla = new FileReader("TablaSimbolos.txt");
		Scanner leer = null;
		leer = new Scanner(tabla);
		while(leer.hasNextLine()){
			String linea = leer.nextLine();
			String[] lineaActual = linea.split(" ");
			int numeroTokens = lineaActual.length;
			int l;
			for(l=0;l<numeroTokens;l++){
				tablaSimbolos.put(lineaActual[l], lineaActual[l+1]);
				l = l+2;
			}
		}
		tabla.close();
		leer.close();
		String prueba = "int";
		String tint = "KWINT";
		assertEquals(tint, tablaSimbolos.get(prueba));
	}

	@Test
	public void testSetFichero() throws IOException{
		FileReader tabla = new FileReader("TablaSimbolos.txt");
		//FileReader prueba = prueba.setFichero(tabla);
	}

	@Test
	public void testGetfichero() throws IOException{
		
		FileReader tabla = new FileReader("TablaSimbolos.txt");
		//FileReader prueba = prueba.getFichero();
	}


}
