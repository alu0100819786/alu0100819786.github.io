public class HelloWorld {
// hola que tal como estamos
}