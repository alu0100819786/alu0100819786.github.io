//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import static org.junit.Assert.*;
import org.junit.Test;
//Implementacion de la clase AdivinaTest que contendr�, los test unitarios para comprobar el correcto
//funcionamiento de la clase Adivina.
public class AdivinaTest {

	Adivina numero = new Adivina(10);
//Contamos con 3 test, uno para el metodo set, otro para el m�todo get, y otro que comprueba en un caso de
//ejemplo el resultado del funcionamiento del metodo Adivinar.
	@Test
	public void testSetNumero() {
		
		numero.setNumero(10);
		int resultadoReal = numero.getNumero();
		
		int resultadoEsperado = 10;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetNumero() {
		
		int resultadoReal = numero.getNumero();
		
		int resultadoEsperado = 10;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testAdivinar() {
		
		int numeroAdivinar = 456;
		int numeroIntroducido = 567;
		numero.Adivinar(numeroAdivinar, numeroIntroducido);
	}

}
