import java.util.*;
import java.io.*;
 
public class Prueba 
{
	//Set grid size
	int l=10,b=10;
	public static void main(String[] args)
	{
 
		Prueba now=new Prueba();
		now.setGame();
	}
	void setGame()
	{
		char[][] config=new char[l][b];
		startGame(config,l,b);
	}
	void startGame(char[][] mat,int l, int b)
	{
		//Scanner s=new Scanner(System.in);
		String ch="";
		float per=0;
		int iteraciones = 40;
			//per=setConfig(mat);
			per= setCustomConfig(mat,"datos.txt");
			display2D(mat);
			System.out.println("Siguiente Estado:");
			//System.out.println((per*100)+"% of grid filled.");
			//System.out.println("Begin? y/n");
			//ch=s.nextLine();
		
		for(int g=0;g<=iteraciones;g++)
		{
			mat=transform(mat,l,b);
			display2D(mat);
 
			System.out.println("Siguiente Estado:");
 
			try
			{
				Thread.sleep(100);
			}
			catch(Exception e)
			{
				System.out.println("Something went horribly wrong.");
			}
 
			//ch=s.nextLine(); esto es para ir pasando linea a linea osea iteracion a iteracion
		}
		//s.close();
		System.out.println("Game Over");
	}
 
	char[][] transform(char[][] mat,int l, int b)
	{
 
		char[][] newmat=new char[l][b];
		for(int i=0;i<l;i++)
			for(int j=0;j<b;j++)
				newmat[i][j]=flip(mat,i,j);
		return newmat;
	}
	char flip(char[][] mat,int i, int j)
	{
		int count=around(mat,i,j);
		if(mat[i][j]=='o')
		{
			if(count<2||count>3)
				return '*';
			return 'o';
		}
		else
		{
			if(count==3)
				return 'o';
			return '*';
		}
	}
	int around(char[][] mat, int i, int j)
	{
		int count=0;
		for(int x=i-1;x<=i+1;x++)
			for(int y=j-1;y<=j+1;y++)
			{
				if(x==i&&y==j)
					continue;
				count+=eval(mat,x,y);
			}
		return count;
	}
	int eval(char[][] mat, int i, int j)
	{
		if(i<0||j<0||i==l||j==b)
			return 0;
		if(mat[i][j]=='o')
			return 1;
		return 0;
	}
 
	float setCustomConfig(char[][] arr,String infile)
	{
		try
		{
			BufferedReader br=new BufferedReader(new FileReader(infile));
			String line;
			for(int i=0;i<arr.length;i++)
			{
				line=br.readLine();
				for(int j=0;j<arr[0].length;j++)
					arr[i][j]=line.charAt(j);
			}
			br.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return 0;
	}
 
	/*float setConfig(char[][] arr)
	{
		//Enter percentage of grid to be filled.
		float per=0.10f;//(float)Math.random();
		for(int i=0;i<arr.length;i++)
			setConfig1D(arr[i],per);
		return per;
	}*/
	void setConfig1D(char[] arr,float per)
	{
		for(int i=0;i<arr.length;i++)
		{
			if(Math.random()<per)
				arr[i]='o';
			else
				arr[i]='*';
		}
	}
	void display2D(char[][] arr)
	{
		for(int i=0;i<arr.length;i++)
			display1D(arr[i]);
		System.out.println();
	}
	void display1D(char[] arr)
	{
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]);
		System.out.println();
	}
}