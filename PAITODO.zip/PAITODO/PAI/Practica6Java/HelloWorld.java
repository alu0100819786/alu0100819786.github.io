public class HelloWorld {
// hola que tal
}