//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 40: Analizador L�xico.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.io.*;
import java.util.Hashtable;
import java.util.Scanner;
//-----Implementaci�n de la clase ALexico, que incluye los m�todos necesarios para un analizar l�xico basico.
public class ALexico {
//-----Declaraci�n de los atributos privados de la clase.
	private FileReader entrada;
//Constructor por defecto.
	public ALexico(){
	}
//Constructor de la clase ALexico, recibe como argumento un objeto FileReader que almacenar� el fichero a leer.
	public ALexico(FileReader entrada){
		this.entrada = entrada;
	}
//Getters y Setters para la clase ALexico.
	public void setFichero(FileReader fichero){
		entrada = fichero;
	}
	public FileReader getfichero(){
		return entrada;
	}
//M�todo Analizador que realizar� el proceso de analisis del fichero de entrada, y escribir� el resultado en el
//fichero de salida elegido previamente.
	public static void Analizador(FileReader entrada, Hashtable<String,String> tablaSimbolos) throws IOException{	
		int j;
		int numeroTokens;
		Scanner s = null;
		FileWriter salida = new FileWriter("salida.txt");
		s = new Scanner(entrada);
		int lineaToken = 1;
		
		while(s.hasNextLine()){
			String linea = s.nextLine();
			String[] lineaActual = linea.split(" ");
			numeroTokens = lineaActual.length;
			
			for(j = 0; j < numeroTokens; j++){
				
				String palabra = lineaActual[j];
				if(tablaSimbolos.containsKey(palabra)){
					salida.write(lineaToken + " " + (linea.indexOf(palabra)+1) + " " + tablaSimbolos.get(palabra) + " " + palabra + "\n");
				}
				else{
					char numero = palabra.charAt(0);
					if(Character.isDigit(numero)){
						salida.write(lineaToken + " " + (linea.indexOf(palabra)+1) + " " + "DOUBLE " + palabra + "\n");
					}
					else{
						char letra = palabra.charAt(0);
						if(Character.isLetter(letra)){
							salida.write(lineaToken + " " + (linea.indexOf(palabra)+1) + " " + "ID " + palabra + "\n");
						}
						else{
							char comentario = palabra.charAt(0);
							if(comentario == '/'){	
							}
							else{
							salida.write(lineaToken + " " + (linea.indexOf(palabra)+1) + " " + palabra + ": TOKEN_ERROR" + "\n");
							}
						}
					}
				}	
			}
			lineaToken++;
		}
		salida.write("EOF");
		s.close();
		entrada.close();
		salida.close();
	}
}