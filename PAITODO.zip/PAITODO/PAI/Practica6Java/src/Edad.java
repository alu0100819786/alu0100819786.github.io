import java.util.ArrayList;
import java.util.Calendar;

public class Edad{
	
	public static void main(String []args){
		
		int k;
		int aux;
		int diaNacimiento;
		int mesNacimiento;
		int añoNacimiento;
		int size = args.length;
		
		ArrayList<Integer> a = new ArrayList<>();
		
		for (k=0; k < size; k++){
			
			a.add(new Integer(args[k]));
			aux= a.get(k);
		}
		
		diaNacimiento = a.get(0);
		mesNacimiento = a.get(1);
		añoNacimiento = a.get(2);
		
		Calendar fechaActual = Calendar.getInstance();
		
		System.out.println("El dia de Nacimiento es: " + diaNacimiento);
		System.out.println("El mes de Nacimiento es: " + mesNacimiento);
		System.out.println("El a�o de Nacimiento es: " + añoNacimiento);
		System.out.println("El dia actual es: " + fechaActual.get(Calendar.DATE));
		System.out.println("El mes actual es: " + fechaActual.get(Calendar.MONTH));
		System.out.println("El a�o actual es: " + fechaActual.get(Calendar.YEAR));
		
		int dia = fechaActual.get(Calendar.DATE) - diaNacimiento;
		int mes = fechaActual.get(Calendar.MONTH) - mesNacimiento;
		int año = fechaActual.get(Calendar.YEAR) - añoNacimiento;
		
		if (mes<0 || (mes==0 && dia<0)){
			
			año--;
		}
		
		System.out.println("La Persona tiene: " + año + " a�os.");
	}
}