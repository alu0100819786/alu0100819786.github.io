//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 5: Game Of Life
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.io.*;
//Implementacion de la clase GameOfLife que contiene los m�todos necesarios para realizar el correcto funcionamiento
//de este algoritmo de John Conway.
public class GameOfLife {
//Declaraci�n de los atributos de la clase.
	private int l;
	private int b;
	private int iteraciones;
	private FileReader entrada;
	private FileWriter salida;
//Constructor por defecto.
	public GameOfLife(){
	}
//Constructor para la clase GameOfLife.
	public GameOfLife(int l, int b, int iteraciones, FileReader entrada, FileWriter salida){
		this.l=l;
		this.b=b;
		this.iteraciones=iteraciones;
		this.entrada=entrada;
		this.salida=salida;
	}
//Colecci�n de seters y getters.
	public void setFilas(int filas){
		l=filas;
	}
	public void setColumnas(int columnas){
		b=columnas;
	}
	public void setIteraciones(int estados){
		iteraciones=estados;
	}
	public void setEntrada(FileReader fichero){
		entrada=fichero;
	}
	public void setSalida(FileWriter fichero){
		salida=fichero;
	}
	public int getFilas(){
		return l;
	}
	public int getColumnas(){
		return b;
	}
	public int getIteraciones(){
		return iteraciones;
	}
	public FileReader getEntrada(){
		return entrada;
	}
	public FileWriter getSalida(){
		return salida;
	}
//Declaraci�n del m�todo SetGame, que recibe como argumentos, los ficheros tanto de entrada como de salida
// y el numero de filas, columnas y estados que tendr� el juego. crea la matriz y llama al m�todo que dar�
// inicio al juego.
	void setGame(FileReader entrada,FileWriter salida,int iteraciones,int l, int b)throws IOException{
		char[][] config=new char[l][b];
		startGame(config,l,b,entrada,salida,iteraciones);
	}
//Declaraci�n del m�todo StartGame, que recibe como argumentos, la matriz, numero de filas, columnas
// e iteraciones y los ficheros de entrada y salida. Este m�todo escribe en el fichero de salida
//el estado inicial del juego que le pasamos desde el fichero de entrada y luego mediante un bucle for
//realiza las iteraciones necesarias llamando al metodo transform para llevar a cabo el procedimiento del
//juego y lo va escribiendo en el fichero de salida, estado a estado, hasta llegaral final del juego.
	void startGame(char[][] mat,int l, int b,FileReader entrada,FileWriter salida,int iteraciones)throws IOException{
		salida.write("Estado Inicial:" + "\n");
		setCustomConfig(mat,entrada,salida);
		display2D(mat,salida);
		salida.write("Siguiente Estado:" + "\n");
		
		for(int g=0;g<=iteraciones;g++){
			mat=transform(mat,l,b);
			display2D(mat,salida);
			salida.write("Siguiente Estado:" + "\n");
		}
		salida.write("Game Over" + "\n");
	}
//Declaraci�n del metodo transform que recibe como argumentos la matriz y el numero de filas y columnas.
//Crea una nueva matriz y a esta nueva matriz la pasa al m�todo flip para su tratado.
	char[][] transform(char[][] mat,int l, int b){
		char[][] newmat=new char[l][b];
		for(int i=0;i<l;i++)
			for(int j=0;j<b;j++)
				newmat[i][j]=flip(mat,i,j,l,b);
		return newmat;
	}
//Declaraci�n del m�todo flip que recibe como argumentos la matriz, el numero de filas y columnas,
//adem�s de las variables i y j pertenecientes al for que las invoca en el m�todo anterior, en este 
//m�todo, creamos una variable count que llamar� al m�todo around para contabilizar el numero de vecinos
//que tiene cada celula y saber si esta viva o muerta o si pasara a estar viva o muerta en el proximo estado.
	char flip(char[][] mat,int i, int j, int l, int b){
		int count=around(mat,i,j,l,b);
		if(mat[i][j]=='o'){
			if(count<2||count>3)
				return '*';
			return 'o';
		}
		else{
			if(count==3)
				return 'o';
			return '*';
		}
	}
//Declaraci�n del m�todo around que recibe como argumentos, la matriz, i , j del for del metodo transform
// y el numero de filas y columnas, este metodo contabilizara el numero de vecinos que tenga cada celula
//y lo devolver� en la variable "count", hace uso del metodo "eval" para evaluar si los vecinos a tratar estan
//vivos o muertos.
	int around(char[][] mat, int i, int j,int l, int b){
		int count=0;
		for(int x=i-1;x<=i+1;x++)
			for(int y=j-1;y<=j+1;y++){
				if(x==i&&y==j)
					continue;
				count+=eval(mat,x,y,l,b);
			}
		return count;
	}
//Declaracion del metodo eval que recibe como argumentos la matriz, i y j del for del metodo anterior, el
// numero de filas y columnas y evalua si el vecino a tratar de la celula tratada es otra celula viva, o
//en caso contrario es una celula muerta.
	int eval(char[][] mat, int i, int j,int l, int b){
		if(i<0||j<0||i==l||j==b)
			return 0;
		if(mat[i][j]=='o')
			return 1;
		return 0;
	}
//Declaracion del m�todo setCustomConfig que trecibe como entrada la matriz y los ficheros de entrada y salida
//Se crea una nueva variable br que ser�a la encargada de leer caracter a caracter el fichero de entrada e ir
//almacenando su contenido en la matriz.
	float setCustomConfig(char[][] arr,FileReader entrada,FileWriter salida)throws IOException{
		try{
			BufferedReader br=new BufferedReader(entrada);
			String line;
			for(int i=0;i<arr.length;i++){
				line=br.readLine();
				for(int j=0;j<arr[0].length;j++)
					arr[i][j]=line.charAt(j);
			}
			br.close();
		}
		catch(Exception e){
			salida.write(e.getMessage());
		}
		return 0;
	}
//Declaracion de los metodos display, que seran los encargados de escribir los diferentes estados en el fichero
//de salida, un bucle for recorre la matriz y va escribiendo y va escribiendo en el fichero, en el metodo display2D,
//llamamos al metodo display1D que es el m�todo que escribe en el fichero y por cada estado, al final el m�todo 
//display2D a�ade una linea de espacio para que la salida del fichero sea mas clara.
	void display2D(char[][] arr,FileWriter salida)throws IOException{
		for(int i=0;i<arr.length;i++)
			display1D(arr[i],salida);
		salida.write("" + "\n");
	}
	void display1D(char[] arr,FileWriter salida)throws IOException{
		for(int i=0;i<arr.length;i++)
			salida.write(arr[i]);
		salida.write("" + "\n");
	}
}

