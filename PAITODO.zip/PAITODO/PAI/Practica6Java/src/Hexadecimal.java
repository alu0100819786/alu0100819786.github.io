//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JFrame;
import java.awt.FlowLayout;
//Implementacion de la clase Hexadecimal que contendr� los metodos para pasar un numero de hexadecimal
//a decimal y comprobar y lanzar exepciones si el numero introducido no es un numero hexadecimal.
public class Hexadecimal extends JFrame{
//Atributo privado de la clase Hexadecimal
	private String nHexa;
//coleccion de metodos set y get para el numero hexadecimal introducido por linea de comandos.
	public void setHexa(String hexa){
		nHexa = hexa;
	}
	public String getHexa(){
		return nHexa;
	}
//Constructor de la clase Hexadecimal.
	public Hexadecimal(String hexa){
		this.nHexa = hexa;
	}
//Constructor de la clase Hexadecimal que creara nuestra interfaz gr�fica a modo de ejemplo
//Donde tendremos un ejemplo de coversion entre un numero hexadecimal a un numero decimal.
	public Hexadecimal() {
	    setLayout(new FlowLayout(FlowLayout.CENTER, 10, 20));
	    add(new JLabel("Numero Hexadecimal:"));
	    add(new JTextField(" ADF "));
	    add(new JLabel("Numero en Decimal"));
	    add(new JTextField(" 2783 "));
	  }
//Metodo Hex2decimal que recibe el numero hexadecimal y realiza los calculos necesarios para convertirlo a
//un nuevo numero decimal.
	public static int Hex2Decimal(String cadena) {
        String digitos = "0123456789ABCDEF";
        cadena = cadena.toUpperCase();
        int val = 0;
        for (int i = 0; i < cadena.length(); i++) {
            char c = cadena.charAt(i);
            int d = digitos.indexOf(c);
            val = 16*val + d;
        }
        return val;
    }
//Metodo isHexNumber que comprueba si el numero introducido es un numero Hexadecimal y de no ser asi
//lanzar� una excepcion indicando que no es un numero hexadecimal.
	public static boolean isHexNumber (String cadena) {
		  try {
		    Long.parseLong(cadena, 16);
		    return true;
		  }
		  catch (NumberFormatException ex) {
			  System.out.println("HexFormatException: Numero no hexadecimal. Entrada Incorrecta.");
		    return false;
		  }
		}
//Metodo main donde se mostrar� la interfaz gr�fica y se conseguira el numero hexadecimal por linea de comandos
//se comprobara que es hexadecimal y se llevara a cabo la conversion.
	public static void main(String []args){
		Hexadecimal frame = new Hexadecimal();
	    frame.setTitle("Conversor de Numeros en Hexadecimal");
	    frame.setLocationRelativeTo(null); // New since JDK 1.4
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(200, 200);
	    frame.setVisible(true);
		int k;
		String hexa="";
		int size = args.length;
		for(k = 0; k < size; k++){
			hexa = args[k];
		}
		if(isHexNumber(hexa)){
			Hex2Decimal(hexa);
			System.out.println(hexa + " en decimal es: " + Hex2Decimal(hexa));
		}
		
		
	}
}
