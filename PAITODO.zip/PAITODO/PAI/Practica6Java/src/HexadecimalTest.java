//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import static org.junit.Assert.*;
import org.junit.Test;
//Implementacion de la clase HexadecimalTest que albergar� los diferentes test para comprobar
//que nuestro programa funciona correctamente.
public class HexadecimalTest {

	Hexadecimal prueba = new Hexadecimal();
//Tenemos test para los metodos Get y set, ademas de un metodo para comprobar si un numero es o no hexadecimal
//y un ultimo test que tratar� con un ejemplo de conversion para comprobar que se realiza correctamente.
	@Test
	public void testSetHexa() {
		prueba.setHexa("ADF");
		
		String resultadoReal = prueba.getHexa();
		
		String resultadoEsperado = "ADF";
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetHexa() {
		prueba.setHexa("ADF");
		String resultadoReal = prueba.getHexa();
		
		String resultadoEsperado = "ADF";
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testHex2Decimal() {
		String numero = "ADF";
		int resultadoReal = prueba.Hex2Decimal(numero);
		int resultadoEsperado = 2783;
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testIsHexNumber() {
		String numero = "ADF";
		
		boolean resultadoReal = prueba.isHexNumber(numero);
		
		boolean resultadoEsperado = true;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

}
