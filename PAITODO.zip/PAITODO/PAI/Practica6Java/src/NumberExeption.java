//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.util.Scanner;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JFrame;
import java.awt.FlowLayout;
//Implementacion de nuestra clase NumberExeption que realizara la suma de dos numeros enteros,
//ademas de comunicarnos si hay un error en la entrada de datos, si introducimos un dato que no sea entero.
public class NumberExeption extends JFrame{
//Atributos privados de la clase NumberExeption.
	private int numero1;
	private int numero2;
//Coleccion de metodos Set y Get para los dos numeros que introducimos.
	public void setNumero1(int n1){
		numero1 = n1;
	}
	public void setNumero2(int n2){	
		numero2 = n2;
	}
	public int getNumero1(){
		return numero1;
	}
	public int getNumero2(){	
		return numero2;
	}
//Constructor de la clase NumberExeption.
	public NumberExeption(int n1, int n2){
		this.numero1=n1;
		this.numero2=n2;
	}
//Constructor de la clase NumberExeption que creara la interfaz gr�fica de prueba para este programa,
//en la cual podremos ver los dos numeros introducidos a modo de ejemplo y su resultado tras sumarlos.
	public NumberExeption() {
	    setLayout(new FlowLayout(FlowLayout.CENTER, 10, 20));
	    add(new JLabel("Primer Numero"));
	    add(new JTextField(" 8 "));
	    add(new JLabel("Segundo Numero"));
	    add(new JTextField(" 5 "));
	    add(new JLabel("Resultado Suma"));
	    add(new JTextField(" 13 "));
	  }
//Metodo sumar que realiza la suma de los dos numeros.
	public static int Sumar(String numero1, String numero2){
		
			int suma = Integer.valueOf(numero1) + Integer.valueOf(numero2);
			return suma;
	}
//Metodo booleano isInt que comprueba si los numeros introducidos son int, o no.
	public static boolean isInt(String numero){
		try {
			Integer.parseInt(numero);
			return true;
		} catch (NumberFormatException nfe){
			return false;
		}
	}
//Metodo main para nuestra clase donde mostramos la interfaz grafica y recibimos los numeros que son escritos por
//teclado.
	public static void main(String []args){
		
		NumberExeption frame = new NumberExeption();
	    frame.setTitle("NumberExeption");
	    frame.setLocationRelativeTo(null); // New since JDK 1.4
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(200, 200);
	    frame.setVisible(true);
		String numero1;
		String numero2;
		Scanner entrada = new Scanner(System.in);
		
		System.out.println ("Escriba el primer numero: ");
		numero1= entrada.next();
		System.out.println ("Escriba el Segundo numero: ");
		numero2= entrada.next();
		while(!isInt(numero1) || !isInt(numero2)){
			System.out.println ("Entrada incorrecta, Introduzca dos numeros enteros!");
			System.out.println ("Escriba el primer numero: ");
			numero1= entrada.next();
			System.out.println ("Escriba el Segundo numero: ");
			numero2= entrada.next();
		}
		Sumar(numero1,numero2);
		System.out.println("El resultado de la suma es: " + Sumar(numero1, numero2));
		entrada.close();
	}
	

}
