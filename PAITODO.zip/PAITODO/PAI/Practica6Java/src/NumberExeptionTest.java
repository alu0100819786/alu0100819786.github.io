//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import static org.junit.Assert.*;
import org.junit.Test;
//Declaracion de la clase NumberExeptionTest que albergar� los test unitarios para nuestra clase NumberExeption.
public class NumberExeptionTest {

	NumberExeption prueba = new NumberExeption();
//tenemos los test necesarios para el correcto funcionamiento de los metodos set y get,Sumar y isInt para comprobar
//tambien que tanto la suma como la comprobacion de si el numero es un entero se realizan correctamente.
	@Test
	public void testSetNumero1() {
		prueba.setNumero1(20);
		
		int resultadoReal = prueba.getNumero1();
		
		int resultadoEsperado = 20;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetNumero2() {
		prueba.setNumero2(20);
		
		int resultadoReal = prueba.getNumero2();
		
		int resultadoEsperado = 20;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetNumero1() {
		prueba.setNumero1(20);
		int resultadoReal = prueba.getNumero1();
		
		int resultadoEsperado = 20;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetNumero2() {
		prueba.setNumero2(20);
		int resultadoReal = prueba.getNumero2();
		
		int resultadoEsperado = 20;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSumar() {
		String numero1 = "10";
		String numero2 = "20";
		int resultadoEsperado=prueba.Sumar(numero1, numero2);
		int resultadoReal = 30;
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testIsInt() {
		String numero = "10";
		
		boolean resultadoEsperado = prueba.isInt(numero);
		
		boolean resultadoReal = true;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

}
