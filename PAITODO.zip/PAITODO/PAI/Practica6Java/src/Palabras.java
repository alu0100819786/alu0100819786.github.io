//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.io.*;
import java.util.HashSet;
import java.util.Scanner;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
//Implementacion de la clase Palabras, que mostrar� en orden alfabeticamente inverso
//las palabras no duplicadas de un archivo que se le pasa al programa.
public class Palabras extends JFrame{
//atributo privado de la clase.
	private FileReader entrada;
//Metodos set y get para conseguir el fichero de entrada
	public void setEntrada(FileReader fichero){
		entrada=fichero;
	}
	public FileReader getEntrada(){
		return entrada;
	}
//Constructor de la clase Palabras.
	public Palabras(FileReader entrada){
		this.entrada = entrada;
	}
//Constructor de la clase palabras que crear� la interfaz gr�fica de ejemplo donde se mostrar�
//las palabras no duplicadas del archivo, su entrada y la salida convertida.
	public Palabras() {
	    JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
	    JButton jbtLeft = new JButton("Hola");
	    JButton jbtCenter = new JButton("Que");
	    JButton jbtRight = new JButton("Tal");
	    jbtLeft.setForeground(Color.BLUE);
	    jbtCenter.setForeground(Color.BLUE);
	    jbtRight.setForeground(Color.BLUE);
	    jbtRight.setToolTipText("Boton derecho");
	    p1.add(jbtLeft);
	    p1.add(jbtCenter);
	    p1.add(jbtRight);
	    p1.setBorder(new TitledBorder("Palabras No Duplicadas"));
	    p1.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));

	    Font largeFont = new Font("TimesRoman", Font.BOLD, 20);
	    Border lineBorder = new LineBorder(Color.BLACK, 2);

	    JPanel p2 = new JPanel(new GridLayout(1, 2, 5, 5));
	    JLabel jlblOrigen = new JLabel("Hola que tal ");
	    JLabel jlblFinal = new JLabel("aloH euq lat");
	    jlblOrigen.setForeground(Color.RED);
	    jlblFinal.setForeground(Color.RED);
	    jlblOrigen.setFont(largeFont);
	    jlblFinal.setFont(largeFont);
	    jlblOrigen.setBorder(lineBorder);
	    jlblFinal.setBorder(lineBorder);
	    p2.add(jlblOrigen);
	    p2.add(jlblFinal);
	    p2.setBorder(new TitledBorder("Resultado Conversi�n"));

	    setLayout(new GridLayout(2, 1, 5, 5));
	    add(p1);
	    add(p2);
	  }
//Metodo invertir que recibe el fichero de entrada, almacena las palabras ducplicadas
//y a aquellas que no estan duplicadas, las invierte.
	public static void Invertir(FileReader entrada){
		HashSet<String> palabras=new HashSet<String>();
		Scanner leer = null;
		leer = new Scanner(entrada);
		while(leer.hasNextLine()){
			String linea = leer.nextLine();
			String[] lineaActual = linea.split(" ");
			int numeroTokens = lineaActual.length;
			int l;
			for(l=0;l<numeroTokens;l++){
				if(palabras.contains(lineaActual[l])){
				}
				else{
					palabras.add(lineaActual[l]);
					String cadenaInvertida="";
					for(int i=lineaActual[l].length()-1; i>=0; i--){
						cadenaInvertida = cadenaInvertida + lineaActual[l].charAt(i);
						
					}
					System.out.println(cadenaInvertida);
				}
			}
		}
	leer.close();	
	}
//Metodo main de la clase donde se muestra la interfaz gr�fica, se consigue el fichero por consola y se llama
//al metodo de Invertir.
	public static void main(String[] args) throws IOException {
		
		JFrame frame = new Palabras();
		frame.setTitle("Palabras No Duplicadas");
		frame.setSize(400, 150);
		frame.setLocationRelativeTo(null); // Center the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		
		int k;
		FileReader entrada = null;
		int size = args.length;
		for(k = 0; k < size; k++){
			entrada = new FileReader(args[k]);
		}
		Invertir(entrada);
		
	}
}
