//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import static org.junit.Assert.*;
import java.io.FileNotFoundException;
import java.io.FileReader;

import org.junit.Test;
//Implementacion de la clase PalabrasTest que albergar� los test necesarios para comprobar el correcto
//funcionamiento de nuestra clase Palabras.
public class PalabrasTest {
	Palabras prueba = new Palabras();
//Tenemos metodos para comprobar que se recibe correctamente el fichero y luego un metodo para comprobar que
//la inversion se realiza correctamente.
	@Test
	public void testSetEntrada() throws FileNotFoundException{
		FileReader entrada = new FileReader("datos.txt");
		prueba.setEntrada(entrada);
		FileReader resultadoReal = prueba.getEntrada();
		
		FileReader resultadoEsperado = entrada;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetEntrada()throws FileNotFoundException {
		FileReader entrada = new FileReader("datos.txt");
		prueba.setEntrada(entrada);
		FileReader resultadoReal = prueba.getEntrada();
		
		FileReader resultadoEsperado = entrada;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testInvertir() throws FileNotFoundException{
		FileReader entrada = new FileReader("Palabras.txt");
		
		prueba.Invertir(entrada);
		
	}

}
