//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
//Implementacion de la clase Syntax que transformar� un codigo de Java para poder visualizarlo en un HTML.
public class Syntax extends JFrame{
//Atributos privados de la clase Syntax
	private FileReader entrada;
	private FileWriter salida;
//Coleccion de metodos set y get para el fichero de entrada y el de salida.
	public void setEntrada(FileReader fichero){
		entrada=fichero;
	}
	public void setSalida(FileWriter fichero){
		salida=fichero;
	}
	public FileReader getEntrada(){
		return entrada;
	}
	public FileWriter getSalida(){
		return salida;
	}
//Constructor de la clase Syntax
	public Syntax(FileReader entrada, FileWriter salida){
		this.entrada = entrada;
		this.salida = salida;
	}
//Constructor de la clase Syntax que creara la interfaz grafica de ejemplo donde preguntar� a que lenguaje
//quieres convertirlo, y mostrar� tambien la salida y entrada.
	public Syntax() {
	    JPanel p1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));
	    JButton jbtLeft = new JButton("HTML");
	    JButton jbtCenter = new JButton("C++");
	    JButton jbtRight = new JButton("Ruby");
	    jbtLeft.setForeground(Color.RED);
	    jbtCenter.setForeground(Color.GREEN);
	    jbtRight.setForeground(Color.BLUE);
	    jbtRight.setToolTipText("Boton derecho");
	    p1.add(jbtLeft);
	    p1.add(jbtCenter);
	    p1.add(jbtRight);
	    p1.setBorder(new TitledBorder("Elige lenguaje de conversi�n"));
	    p1.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));

	    Font largeFont = new Font("TimesRoman", Font.BOLD, 20);
	    Border lineBorder = new LineBorder(Color.BLACK, 2);

	    JPanel p2 = new JPanel(new GridLayout(1, 2, 5, 5));
	    JLabel jlblRed = new JLabel("Fichero Origen");
	    JLabel jlblOrange = new JLabel("Fichero Convertido");
	    jlblRed.setForeground(Color.RED);
	    jlblOrange.setForeground(Color.ORANGE);
	    jlblRed.setFont(largeFont);
	    jlblOrange.setFont(largeFont);
	    jlblRed.setBorder(lineBorder);
	    jlblOrange.setBorder(lineBorder);
	    p2.add(jlblRed);
	    p2.add(jlblOrange);
	    p2.setBorder(new TitledBorder("Resultado Conversi�n"));

	    setLayout(new GridLayout(2, 1, 5, 5));
	    add(p1);
	    add(p2);
	  }
//Metodo analizador que recibe como parametros los ficheros de entrada y salida, ademas de las palabras reservadas
//de Java para poder realizar la conversion y asignarle un color a cada uno.
public static void Analizador(FileReader entrada, FileWriter salida, HashSet<String> palabrasReservadas) throws IOException{
	int j;
	int numeroTokens;
	Scanner s = null;
	s = new Scanner(entrada);
	salida.write("<html>"+ "\n");
	salida.write("<body>"+ "\n");
	while(s.hasNextLine()){
		String linea = s.nextLine();
		String[] lineaActual = linea.split(" ");
		numeroTokens = lineaActual.length;
		
		for(j = 0; j < numeroTokens; j++){
			String palabra = lineaActual[j];
			if(palabrasReservadas.contains(palabra)){
				salida.write("<b>" + palabra + "</b>" + " ");
			}
			else{
				if(linea.charAt(0)=='/' && (linea.charAt(1)=='*' || linea.charAt(1)=='/')){
					salida.write("<p style=\"color:#3CFF00;\">" + linea + "</p>");
					j=numeroTokens -1;
				}
				else{
					salida.write("<p style=\"color:#003CFF;\">" + palabra + "</p>");
				}
			}
		}
	}
	salida.write("</body>"+ "\n");
	salida.write("</html>"+ "\n");
	s.close();
}
//Metodo main de nuestra clase Syntax donde se muestra la interfaz grafica de ejemplo, se consiguen
//los ficheros de entrada y salida, y se llama al metodo Analizador.
public static void main(String[] args) throws IOException{
		JFrame frame = new Syntax();
		frame.setTitle("Syntax");
		frame.setSize(400, 150);
		frame.setLocationRelativeTo(null); // Center the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		HashSet<String> palabrasReservadas=new HashSet<String>();
		FileReader tabla = new FileReader("PalabrasJava.txt");
		Scanner leer = null;
		leer = new Scanner(tabla);
		while(leer.hasNextLine()){
			String linea = leer.nextLine();
			String[] lineaActual = linea.split(" ");
			int numeroTokens = lineaActual.length;
			int l;
			for(l=0;l<numeroTokens;l++){
				palabrasReservadas.add(lineaActual[l]);
			}
		}	
		int k;
		String aux;
		FileReader entrada = null;
		FileWriter salida = null;
		int size = args.length;
		ArrayList<String> a = new ArrayList<>();
			for (k=0; k < size; k++){	
				a.add(new String(args[k]));
				aux= a.get(k);
			}
		entrada = new FileReader(a.get(0));
		salida = new FileWriter(a.get(1));
		Analizador(entrada, salida, palabrasReservadas);
		salida.close();
		leer.close();
	}		
}