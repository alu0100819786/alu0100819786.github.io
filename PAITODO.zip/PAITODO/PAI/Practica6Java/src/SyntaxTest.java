//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import static org.junit.Assert.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import org.junit.Test;
//implementacion de nuestra clase SyntaxTest que albergar� los test necesarios para comprobar el correcto 
//funcionamiento de nuestra clase Syntax
public class SyntaxTest {
	
	Syntax prueba = new Syntax();
//Disponemos de los metodos para comprobar los setters y getters
	@Test
	public void testSetEntrada() throws FileNotFoundException{
		FileReader entrada = new FileReader("datos.txt");
		prueba.setEntrada(entrada);
		FileReader resultadoReal = prueba.getEntrada();
		
		FileReader resultadoEsperado = entrada;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetSalida() throws IOException{
		FileWriter salida = new FileWriter("salida.txt");
		prueba.setSalida(salida);
		FileWriter resultadoReal = prueba.getSalida();
		
		FileWriter resultadoEsperado = salida;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetEntrada() throws FileNotFoundException {
		FileReader entrada = new FileReader("datos.txt");
		prueba.setEntrada(entrada);
		FileReader resultadoReal = prueba.getEntrada();
		
		FileReader resultadoEsperado = entrada;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetSalida() throws IOException {
		FileWriter salida = new FileWriter("salida.txt");
		prueba.setSalida(salida);
		FileWriter resultadoReal = prueba.getSalida();
		
		FileWriter resultadoEsperado = salida;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

}
