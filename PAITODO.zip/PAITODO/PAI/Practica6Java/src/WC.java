import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class WC {
	private FileReader entrada;
	
	public void setEntrada(FileReader fichero){
		entrada=fichero;
	}
	public FileReader getEntrada(){
		return entrada;
	}
	
	public static int Contador(FileReader entrada){
		int contadorLineas =0;
		Scanner leer = null;
		leer = new Scanner(entrada);
		while(leer.hasNextLine()){
			contadorLineas++;
		}
		leer.close();
		return contadorLineas;
		//System.out.println("Numero de Lineas: "+ contadorLineas);
		
	}
	public static void main(String[] args) throws IOException{
		
		int k;
		String aux;
		FileReader entrada = null;
		int size = args.length;
		ArrayList<String> a = new ArrayList<>();
			for (k=0; k < size; k++){	
				a.add(new String(args[k]));
				aux= a.get(k);
			}
		entrada = new FileReader(a.get(0));
		Contador(entrada);
		System.out.println("hola");
		entrada.close();
	}
	
	
}
