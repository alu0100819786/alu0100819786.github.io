//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 7: Conversor de Divisas con MVC.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es

//Creaccion de la clase Modelo, que albergar� los metodos necesarios para llevar a cabo las conversiones
//de euros a las otras monedas.
public class Modelo {
//Definicion del atributo privado de la clase que almacenar� los euros que introduzcamos por la consola
//adem�s de las constantes para identificar el cambio de euros a las demas monedas.
	 private static double euros;
	 static final double libraEsterlina = 0.866663;
	 static final double dolarEstadounidense = 1.07458;
	 static final double francoSuizo = 1.0723;
	 static final double francoFrances = 6.56;
	 static final double marcoAleman = 1.95583;
	 static final double liraItaliana = 1936.27;
//Constructor de la clase Modelo.
	 public Modelo(){
	 }
//Definicion de los metodos set y get para manejar el valor de los euros introducidos por la consola
	 public static void setEuros(Double moneda) {
		 euros = moneda;
	 }
	 public double getEuros(){
		 return euros;
	 }
//Definicion del metodo ConvertirALibras que devuelve el valor de los euros introducidos convertido a libras.
	 public double convertirALibras() {
		 return euros * libraEsterlina;
	 }
//Definicion del metodo ConvertirADolares que devuelve el valor de los euros introducidos convertido a dolares.
	 public double convertirADolares() {
		 return euros * dolarEstadounidense;
	 }
//Definicion del metodo ConvertirAFrancoSuizo que devuelve el valor de los euros introducidos convertido a francos Suizos.
	 public double convertirAFrancoSuizo() {
		 return euros * francoSuizo;
	 }
//Definicion del metodo ConvertirAFrancoFrances que devuelve el valor de los euros introducidos convertido a francos franceses.
	 public double convertirAFrancoFrances() {
		 return euros * francoFrances;
	 }
//Definicion del metodo ConvertirAMarcosAlemanes que devuelve el valor de los euros introducidos convertido a marcos alemanes.
	 public double convertirAMarcoAleman() {
		 return euros * marcoAleman;
	 }
//Definicion del metodo ConvertirALiraItaliana que devuelve el valor de los euros introducidos convertido a liras italianas.
	 public double convertirALiraItaliana() {
		 return euros * liraItaliana;
	 }
}
