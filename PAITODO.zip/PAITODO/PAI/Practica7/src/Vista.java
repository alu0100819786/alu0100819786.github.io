//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 7: Conversor de Divisas con MVC.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.awt.FlowLayout;	 
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
//Definicion de la clase Vista que incorporar� el cuerpo de nuestra interfaz gr�fica, crearemos los textos y los
//cuadros de texto donde luego se pondr�n los resultados de las conversiones.
public class Vista extends JFrame{
	public JTextField aEuros, aLibras, aDolares, aFrancosSuizos, aFrancosFranceses, aMarcosAlemanes, aLirasItalianas;
//Constructor de la clase Vista.  
	public Vista() {
//Definimos la estrcutura base de nuestra vista y creamos los textos.
		setLayout(new FlowLayout(FlowLayout.CENTER, 10, 20));
		add(new JLabel("Euros Introducidos: "));
		add(aEuros = new JTextField(10));
		add(new JLabel("Conversion a Libras: 1EUR=0.866663"));
		add(aLibras= new JTextField(10));
		add(new JLabel("Conversion a Dolares: 1EUR=1.07458"));
		add(aDolares = new JTextField(10));
		add(new JLabel("Conversion a Francos Suizos: 1EUR=1.0723"));
		add(aFrancosSuizos = new JTextField(10));
		add(new JLabel("Conversion a Francos Franceses: 1EUR=6.56"));
		add(aFrancosFranceses  = new JTextField(10));
		add(new JLabel("Conversion a Marcos Alemanes: 1EUR=1.95583"));
		add(aMarcosAlemanes = new JTextField(10));
		add(new JLabel("Conversion a LirasItalianas: 1EUR=1936.27"));
		add(aLirasItalianas = new JTextField(10));
	}
}
