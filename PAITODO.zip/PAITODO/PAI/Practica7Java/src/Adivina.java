//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 6: Fundamentos de interfaces graficas de Usuario.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JFrame;
import java.awt.GridLayout;
//Implementacion de la clase Adivina que contentra los metodos para desarollar un programa
//el cual generara un numero aleatorio de 3 cifras y tendremos que intentar adivinarlo para ganar
//el premio.
public class Adivina extends JFrame{
//Atributo privado de la clase Adivina, almacenar� el numero introducido por el usuario.
	private int numero;
//Constructor de la clase que crear� la interfaz gr�fica que no ser� operativa, sino de ejemplo.
	public Adivina() {
//Creamos el GridLayout y le a�adimos labers y text fields para rellenarlo.
	    setLayout(new GridLayout(3, 2, 5, 5));
	    add(new JLabel("Numero Aleatorio"));
	    add(new JTextField("442"));
	    add(new JLabel("Numero Introducido"));
	    add(new JTextField("567"));
	    add(new JLabel("Resultado"));
	    add(new JTextField("Ganas 0 euros"));
	  }
//Constructor de la clase Adivina.
	public Adivina(int n){
		this.numero=n;
	}
//Metodos get y set para tratar con el numero que ingresamos al programa.
	public void setNumero(int n){
		numero = n;
	}
	public int getNumero(){
		return numero;
	}
//Metodo Aleatorio, que generar� un numero aleatorio de 3 cifras.
	public static int Aleatorio(){
		
		int numero = (int)(Math.random() * 899) + 100;
		return numero;

	}
//Metodo adivinar donde se le pasaran, el numero a adivinar y el numero introducido y 
// comprobar� si hemos acertado el numero y el premio que conseguimos.
	public static void Adivinar(int numeroAdivinar, int numeroIntroducido){
		
		System.out.println("Numero a adivinar: " + numeroAdivinar);
		System.out.println("Numero introducido: " + numeroIntroducido);
		
		if(numeroAdivinar == numeroIntroducido){
			
			System.out.println("Has Acertado el numero: Ganas 10.000 Euros");
		}
		else{
			
			int terceroAdi = numeroAdivinar%10;
	        numeroAdivinar = numeroAdivinar/10;
	        int segundoAdi = numeroAdivinar%10;
	        numeroAdivinar = numeroAdivinar/10;
	        int primeroAdi = numeroAdivinar%10;
	        int terceroIntro = numeroIntroducido%10;
	        numeroIntroducido = numeroIntroducido/10;
	        int segundoIntro = numeroIntroducido%10;
	        numeroIntroducido = numeroIntroducido/10;
	        int primeroIntro = numeroIntroducido%10;
	        
	        if((terceroAdi == terceroIntro || terceroAdi == segundoIntro || terceroAdi == primeroIntro) && (segundoAdi == terceroIntro || segundoAdi == segundoIntro || segundoAdi == primeroIntro) && (primeroAdi == terceroIntro || primeroAdi == segundoIntro || primeroAdi == primeroIntro)){
	        
	        	System.out.println("Todos Los D�gitos coinciden: Ganas 3.000 Euros");
	        }
	        else{
	        	if(((terceroAdi == terceroIntro || terceroAdi == segundoIntro || terceroAdi == primeroIntro) && (segundoAdi == terceroIntro || segundoAdi == segundoIntro || segundoAdi == primeroIntro)) || (terceroAdi == terceroIntro || terceroAdi == segundoIntro || terceroAdi == primeroIntro) && (primeroAdi == terceroIntro || primeroAdi == segundoIntro || primeroAdi == primeroIntro) || (primeroAdi == terceroIntro || primeroAdi == segundoIntro || primeroAdi == primeroIntro) && (segundoAdi == terceroIntro || segundoAdi == segundoIntro || segundoAdi == primeroIntro)){
	        		System.out.println("Dos digito coincide: Ganas 2.000 Euros");
	        	}
	        	else{
	        		if((terceroAdi == terceroIntro || terceroAdi == segundoIntro || terceroAdi == primeroIntro) || (segundoAdi == terceroIntro || segundoAdi == segundoIntro || segundoAdi == primeroIntro) || (primeroAdi == terceroIntro || primeroAdi == segundoIntro || primeroAdi == primeroIntro)){
	        
	        		System.out.println("Un digito coincide: Ganas 1.000 Euros");
	        	}
	        	else{
	        		System.out.println("No Has acertado ningun numero: Ganas 0 Euros");
	        	}
	        }
	        }
		}
	}
//Metodo Main donde mostramos nuestra interfaz gr�fica y donde conseguimos el numero introducido por linea
//de comandos para el funcionamiento del programa.
	public static void main(String[] args) {
		Adivina frame = new Adivina(); frame.setTitle("Adivina El numero.");
	    frame.setLocationRelativeTo(null);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(200, 125);
	    frame.setVisible(true);
		int k;
		int aux;
		int numeroIntroducido;
		int numeroAdivinar;
		int size = args.length;
		ArrayList<Integer> a = new ArrayList<>();
		
		for (k=0; k < size; k++){
			
			a.add(new Integer(args[k]));
			aux= a.get(k);
		}
		numeroIntroducido = a.get(0);
		numeroAdivinar = Aleatorio();
		Adivinar(numeroAdivinar, numeroIntroducido);
		

	}

}
