//Programación de Aplicaciones Interactivas (PAI)
//Practica 7: Conversor de Divisas con MVC.
//Autor: Gabriel Melián Hernández
//e-mail: alu0100819786@ull.edu.es	
import javax.swing.JFrame;
//Definicion de nuestra clase Controlador que incorporá los metodos para rellenar los cuadros de textos
//de nuestra interfaz grafica con los resultados de las operaciones realizadas en la clase modelo.
public class Controlador{
//Definicion de los atributos privados de la clase Controlador.
	private Modelo modelo;
	private Vista vista;
//Constructor de la clase Controlador.
	public Controlador(Modelo modelo, Vista vista) {
		this.modelo = modelo;
		this.vista = vista;
	}
//Implementacion del metodo iniciar vista que da dimensiones y crea nuestra interfaz ademas de introducir
//los valores correspondientes en los cuadros de texto.
	public void iniciarVista() {
		vista.setTitle("Conversor de Divisas");
		vista.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		vista.setLocationRelativeTo(null);
		vista.setVisible(true);
		vista.setSize(350, 600);
		vista.aEuros.setText(String.valueOf(String.format("%.2f", modelo.getEuros())));
		vista.aLibras.setText(String.valueOf(String.format("%.2f", modelo.convertirALibras())));
		vista.aDolares.setText(String.valueOf(String.format("%.2f", modelo.convertirADolares())));
		vista.aFrancosSuizos.setText(String.valueOf(String.format("%.2f", modelo.convertirAFrancoSuizo())));
		vista.aFrancosFranceses.setText(String.valueOf(String.format("%.2f", modelo.convertirAFrancoFrances())));
		vista.aMarcosAlemanes.setText(String.valueOf(String.format("%.2f", modelo.convertirAMarcoAleman())));
		vista.aLirasItalianas.setText(String.valueOf(String.format("%.2f", modelo.convertirALiraItaliana())));
	}
}
