//Programación de Aplicaciones Interactivas (PAI)
//Practica 7: Conversor de Divisas con MVC.
//Autor: Gabriel Melián Hernández
//e-mail: alu0100819786@ull.edu.es
import static org.junit.Assert.*;
import org.junit.Test;
//Implementacion de nuestra Clase modeloTest que contendrá los test necesarios para comprobar el funcionamiento
//de nuestra los metodos de conversion usados en nuestro programa.
public class ModeloTest {
	Modelo prueba = new Modelo();
	private static final double DELTA = 1e-15;

	@Test
	public void testSetEuros() {
		prueba.setEuros(5.36);
		double resultadoReal = prueba.getEuros();
		double resultadoEsperado = 5.36;
		
		assertEquals(resultadoReal, resultadoEsperado,DELTA);
	}

	@Test
	public void testGetEuros() {
		prueba.setEuros(5.36);
		double resultadoReal = prueba.getEuros();
		double resultadoEsperado = 5.36;
		
		assertEquals(resultadoReal, resultadoEsperado,DELTA);
	}

	@Test
	public void testConvertirALibras() {
		prueba.setEuros(5.36);
		double resultadoReal = prueba.convertirALibras();
		double resultadoEsperado = 4.64531368;
		assertEquals(resultadoReal, resultadoEsperado,DELTA);
	}

	@Test
	public void testConvertirADolares() {
		prueba.setEuros(5.36);
		double resultadoReal = prueba.convertirADolares();
		double resultadoEsperado = 5.7597488;
		assertEquals(resultadoReal, resultadoEsperado,DELTA);
	}

	@Test
	public void testConvertirAFrancoSuizo() {
		prueba.setEuros(5.36);
		double resultadoReal = prueba.convertirAFrancoSuizo();
		double resultadoEsperado = 5.747528;
		assertEquals(resultadoReal, resultadoEsperado,DELTA);
	}

	@Test
	public void testConvertirAFrancoFrances() {
		prueba.setEuros(5.36);
		double resultadoReal = prueba.convertirAFrancoFrances();
		double resultadoEsperado = 35.1616;
		assertEquals(resultadoReal, resultadoEsperado,DELTA);
	}

	@Test
	public void testConvertirAMarcoAleman() {
		prueba.setEuros(5.36);
		double resultadoReal = prueba.convertirAMarcoAleman();
		double resultadoEsperado = 10.4832488;
		assertEquals(resultadoReal, resultadoEsperado,DELTA);
	}

	@Test
	public void testConvertirALiraItaliana() {
		prueba.setEuros(5.36);
		double resultadoReal = prueba.convertirALiraItaliana();
		double resultadoEsperado = 10378.4072;
		assertEquals(resultadoReal, resultadoEsperado,DELTA);
	}

}
