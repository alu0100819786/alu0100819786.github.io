//Programación de Aplicaciones Interactivas (PAI)
//Practica 7: Conversor de Divisas con MVC.
//Autor: Gabriel Melián Hernández
//e-mail: alu0100819786@ull.edu.es
import java.util.ArrayList;
//Definicion de nuestra clase PruebaConversor donde recibiremos la cantidad de euros introducida,
//y llamaremos a las clases modelo y vista para crearlos y llamaremos al metodo iniciar vista para llevar a cabo
//la conversion.
public class PruebaConversor {
	public static void main(String[] args) {
		double eurosIntroducidos;
		int k;
		Double aux;
		int size = args.length;
		ArrayList<Double> a = new ArrayList<>();
			
		for (k=0; k < size; k++){
			a.add(new Double(args[k]));
			aux= a.get(k);
		}
		eurosIntroducidos = a.get(0);
		Modelo modelo = new Modelo();
		Modelo.setEuros(eurosIntroducidos);	
	    Vista vista = new Vista();
	    Controlador controlador = new Controlador(modelo, vista);
	    controlador.iniciarVista();
	 	}
}
