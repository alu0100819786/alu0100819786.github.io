public class CasiCero{

	public static boolean equals(double num1, double num2){

		return num1==num2;

	}	

	public static void main(String []args){

		double numero1 = 10;
		double numero2 = 10.00002;
		double numero3 = 10.00000;

		System.out.println("El numero " + numero1 + " y el numero " + numero2 + " son iguales?: " + equals(numero1, numero2));
		System.out.println("El numero " + numero1 + " y el numero " + numero3 + " son iguales?: " + equals(numero1, numero3));

	}

}
