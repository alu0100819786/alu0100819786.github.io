public class ClassString {

	public static int contadorCaracteres(String cadena, char caracter){

		int posicion;
		int contador=0;

		posicion = cadena.indexOf(caracter);
		
		while(posicion != -1){

			contador++;
			posicion = cadena.indexOf(caracter, posicion + 1);

		}
		return contador;

	}

	public static void main(String []args){

		String texto = new String("Hola Mundo");

		char caracterMinus = 'a';
		char caracterMayus = 'A';

		System.out.println("En la cadena: " + texto);
		System.out.println("El numero de 'a' es: " + contadorCaracteres(texto, caracterMinus));
		System.out.println("El numero de 'A' es: " + contadorCaracteres(texto, caracterMayus));
	}
}
