import java.util.ArrayList;
import java.util.Calendar;

public class Edad{


	public static void main (String []args){


		int k;
		int n;
		int diaNacimiento;
		int mesNacimiento;
		int añoNacimiento;
		int size = args.length;

		ArrayList<Integer> a = new ArrayList<>();

			for (k = 0; k < size; k++) {
	
				a.add( new Integer(args[k]) );
				n = a.get(k);	
			}

		diaNacimiento = a.get(0);
		mesNacimiento = a.get(1);
		añoNacimiento = a.get(2);

		Calendar fechaActual = Calendar.getInstance();

		System.out.println( "El dia de nacimiento es: " + diaNacimiento);
		System.out.println( "El mes de nacimiento es: " + mesNacimiento);
		System.out.println( "El año de nacimineto es: " + añoNacimiento);
		System.out.println( "el dia actual es: " + fechaActual.get(Calendar.DATE));
		System.out.println( "el mes actual es: " + fechaActual.get(Calendar.MONTH));
		System.out.println( "el año actual es: " + fechaActual.get(Calendar.YEAR));

		int dia = fechaActual.get(Calendar.DATE) - diaNacimiento;
		int mes = fechaActual.get(Calendar.MONTH) - mesNacimiento;
		int año = fechaActual.get(Calendar.YEAR) - añoNacimiento;

		if (mes<0 || (mes==0 && dia<0)){

			año --;
		}

		System.out.println("La Persona tiene: " + año + " años.");

	}

}
