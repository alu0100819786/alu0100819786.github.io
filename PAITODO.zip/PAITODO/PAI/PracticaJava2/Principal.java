class Principal extends Racional{

	Principal(int num, int den){

		super(num,den);
	}	


	public static void main (String []args){
	
		Racional r1 = new Racional (2,4);
		Racional r2 = new Racional (1,2);

		System.out.println("¿R1 tiene denominador distinto de cero?: " + denominador(r1));
		System.out.println("¿R2 tiene denominador distinto de cero?: " + denominador(r2));
		System.out.println("El resultado de la suma es: " + suma(r1, r2));
		System.out.println("El resultado de la resta es: " + resta(r1, r2));
		System.out.println("El resultado del producto es: " + multiplicar(r1, r2));
		System.out.println("El resultado de la division es: " + dividir(r1, r2));
		System.out.println("Son R1 y R2 iguales: " + igual(r1.simplificar(),r2.simplificar()));
		//System.out.println("Prueba del boolean mayor: " + mayor(r1,r2));
		//System.out.println("Prueba del boolean menor: " + menor(r1,r2));

	}
}
