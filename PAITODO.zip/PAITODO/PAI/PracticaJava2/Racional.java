public class Racional{

	private int num;
	private int den;


	public Racional(int num, int den){

		this.num = num;
		this.den = den;
	}

	public String toString(){

		return String.valueOf(num) + '/' + String.valueOf(den);
	}

	public static boolean denominador(Racional r1){

		return (r1.den!=0);
	}

	public static Racional suma(Racional r1, Racional r2){

		if(denominador(r1)==true && denominador(r2)==true){

			Racional sum = new Racional(r1.num*r2.den+r1.den*r2.num,r1.den*r2.den);
			return sum;
		}
		else{
			
			Racional error = new Racional(0,0);
			return error;
		}
	}

	public static Racional resta(Racional r1, Racional r2){

		if(denominador(r1)==true && denominador(r2)==true){

			Racional dif = new Racional(r1.num*r2.den-r1.den*r2.num,r1.den*r2.den);
			return dif;
		}
		else{
			
			Racional error = new Racional(0,0);
			return error;
		}
	}

	public static Racional multiplicar(Racional r1, Racional r2){

		if(denominador(r1)==true && denominador(r2)==true){

			Racional mult = new Racional(r1.num*r2.num,r1.den*r2.den);
			return mult;
		}
		else{
			
			Racional error = new Racional(0,0);
			return error;
		}
	}

	public static Racional dividir(Racional r1, Racional r2){

		if(denominador(r1)==true && denominador(r2)==true){

			Racional sum = new Racional(r1.num*r2.den,r1.den*r2.num);
			return sum;
		}
		else{
			
			Racional error = new Racional(0,0);
			return error;
		}
	}

	private int mcd(){

		int numerador = Math.abs(num);
		int denominador = Math.abs(den);

		if (denominador==0) return numerador;

		int resto;
	
		while(denominador!=0){
		
			resto=numerador%denominador;
			numerador=denominador;
			denominador=resto;
		}
		return numerador;
	}
	
	public Racional simplificar(){

		return new Racional(num/mcd(), den/mcd());
	}

	public static boolean igual(Racional r1, Racional r2){

		return (r1.num==r2.num && r1.den==r2.den);

	}
	
	/*public static boolean mayor(Racional r1, Racional r2){

		return r1 > r2;
	}

	public static boolean menor(Racional r1, Racional r2){

		return r1 < r2;
	}*/

}
