/*Programacion de Aplicaciones Interactivas (PAI)
Practica 3: Clase Fecha.
Autor: Gabriel Melian Hernandez
e-mail: alu0100819786@ull.edu.es */

/*-----Implementacion de la Clase Fecha-----*/

public class Fecha {
	
	
/*-----Definimos los atributos privados de la clase-----*/
	
	private  int dia;
	private  int mes;
	private  int anio;
	

/*-----Constructor por defecto para la clase.-----*/
	
	public Fecha(){
		
	}
	
/*-----Constructor para la clase Fecha, donde se le pasan tres parametros
correspondientes al dia, mes y anio, todos ellos del tipo "int"-----*/
	
	public Fecha(int dia, int mes, int anio){
		
		this.dia = dia;
		this.mes = mes;
		this.anio = anio;
	}
	
/*-----Setters y Getters-----
Coleccion de metodos set y get para poder acceder a los metodos
Con los setters modificamos el atributo, mientras que con get cogemos su valor-----*/
	
	public void setDia(int d){
		
		dia = d;
	}
	
	public void setMes(int m){
		
		mes = m;
	}
	
	public void setAnio(int a){
		
		anio = a;
	}
	
	public int getDia(){
		
		return dia;
	}

	public int getMes(){
		
		return mes;
	}

	public int getAnio(){
	
		return anio;
	}
	
/*-----Metodo setFecha, que acude al metodo esFechaValida() para comprobar
si una fecha introducida es valida y si es valida procede a realizar
un proceso como un metodo set, mientras que si no es valida, devuelve una excepcion-----*/
	public void setFecha(int d, int m, int a){
		
		if(esFechaValida()){
			
			dia = d;
			mes = m;
			anio = a;
		}
		else{
			throw new IllegalArgumentException("dia, mes o anio, no valido");
		}
	}
	
/*-----Metodo esBisiesto(), implementacion de un metodo que comprueba
si el anio de la fecha introducida es bisiesto o no.-----*/
	
	public boolean esBisiesto(){
		
		return (anio % 4 == 0 && anio % 100 != 0 || anio % 400 == 0);
	}
	
/*-----Metodo esFechaValida(), implementacion de un metodo que comprueba
si una fecha introducida es valida o no y devuelve "true" (es un metodo booleano)
si la fecha es valida.----*/
	
	public boolean esFechaValida(){
		
		boolean diaCorrecto;
		boolean mesCorrecto;
		boolean anioCorrecto;
		
		anioCorrecto = anio > 0;
		mesCorrecto = mes >= 1 && mes <= 12;
		
		switch (mes){
		
			case 2:
				if(esBisiesto()){
					diaCorrecto = dia >= 1 && dia <= 29;
				}
				else{
					diaCorrecto = dia >= 1 && dia <= 28;
				}
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				diaCorrecto = dia >= 1 && dia <= 30;
				break;
			default:
				diaCorrecto = dia >= 1 && dia <= 31;
		}
		
		return diaCorrecto && mesCorrecto && anioCorrecto;
	}
	
/*-----Metodo getDiaDeSemana(), implementacion de un metodo, que devuelve
un entero correspondiente al dia de la semana de la fecha que hemos introducido
comenzando devolviendo un valor de '0' para el Sabado.-----*/
	
	public int getDiaDeSemana(){
		
		int mesFormula;
		
		if(esBisiesto()){
			if(mes == 10){
				
				mesFormula = 0;
			}
			else{
				if(mes == 5){
					
					mesFormula = 1;
				}
				else{
					if(mes == 2 || mes == 8){
						
						mesFormula = 2;
					}
					else{
						if(mes == 3 || mes == 11){
							
							mesFormula = 3;
						}
						else{
							if(mes == 6){
								
								mesFormula = 4;
							}
							else{
								if(mes == 9 || mes == 12){
									
									mesFormula = 5;
								}
								else{
									
									mesFormula = 6;
								}
							}
						}
					}
				}
			}
		}
		else{
			if(mes == 1 || mes == 10){
				
				mesFormula = 0;
			}
			else{
				if(mes == 5){
					
					mesFormula = 1;
				}
				else{
					if(mes == 8){
						
						mesFormula = 2;
					}
					else{
						if(mes == 2 || mes == 3 || mes == 11 ){
							
							mesFormula = 3;
						}
						else{
							if(mes == 6){
								
								mesFormula = 4;
							}
							else{
								if(mes == 9 || mes == 12){
									
									mesFormula = 5;
								}
								else{
									
									mesFormula = 6;
								}
							}
						}
					}
				}
		}
	}
		if(anio>1582){

			return (dia + mesFormula + anio%100 + (anio/100)%4 + (((anio%100)%4)+(anio%100)))%7;
		}
		else{

			return (dia + mesFormula + anio%100 + (anio/100)%4 + (((anio%100)%7)+(anio%100)))%7;
		}

	}
	
/*-----Metodo toString(), implementacion de un metodo que devuelve por pantalla
la fecha introducida, en un formato establecido por el programador.-----*/
	
	public String toString(){
		
		String diaSemana;
		String mesString;
		
		if(getDiaDeSemana() == 0){
			
			diaSemana = "Sabado";
		}
		else{
			if(getDiaDeSemana() == 1){
				
				diaSemana = "Domingo";
			}
			else{
				if(getDiaDeSemana() == 2){
					
					diaSemana = "Lunes";
				}
				else{
					if(getDiaDeSemana() == 3){
						
						diaSemana = "Martes";
					}
					else{
						if(getDiaDeSemana() == 4){
							
							diaSemana = "Miercoles";
						}
						else{
							if(getDiaDeSemana() == 5){
								
								diaSemana = "Jueves";
							}
							else{
								
								diaSemana = "Viernes";
							}
						}
					}
				}
			}
		}
		if(mes == 1){
			
			mesString = "Enero";
		}
		else{
			if(mes == 2){
				
				mesString = "Febrero";
			}
			else{
				if(mes == 3){
					
					mesString = "Marzo";
				}
				else{
					if(mes == 4){
						
						mesString = "Abril";
					}
					else{
						if(mes == 5){
							
							mesString = "Mayo";
						}
						else{
							if(mes == 6){
								
								mesString = "Junio";
							}
							else{
								if(mes == 7){
									
									mesString = "Julio";
								}
								else{
									if(mes == 8){
										
										mesString = "Agosto";
									}
									else{
										if(mes == 9){
											
											mesString = "Septiembre";
										}
										else{
											if(mes == 10){
												
												mesString = "Octubre";
											}
											else{
												if(mes == 11){
													
													mesString = "Noviembre";
												}
												else{
													
													mesString = "Diciembre";
												}
												
											}
										}
									}
								}
								
							}
							
						}
						
					}
				}
				
			}
		}
		
		
		return diaSemana + ", " + String.valueOf(dia) + " de " + mesString + " de " + String.valueOf(anio);
	}
	
/*-----Implementacion de metodos para conseguir el dia, mes y anio, tanto siguientes, como anteriores
a la fecha que habiamos introducido.(si el anio es un valor mayor que 9999, 
los metodos devuelven una excepcion-----*/

	public void siguienteDia(){
		
		dia++;
		
		if(!esFechaValida()){
			
			dia = 1;
			mes++;
			
			if(!esFechaValida()){
				
				mes = 1;
				anio++;
			}
		}
		if(anio>9999){
			
			throw new IllegalStateException("Anio fuera de Rango");
		}
	}
	
	public void anteriorDia(){
		
		dia--;
		
		if(!esFechaValida()){
			
			mes--;
			
			if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
				
				dia = 30;
			}
			else{
				if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12){
					
					dia = 31;
				}
				else{
					if (esBisiesto()){
						dia=29;
					}
					else{
						dia=28;
					}
				}
				
			}
			if(!esFechaValida()){
				dia = 31;
				mes= 12;
				anio--;
			}
		}
		if(anio>9999){
			
			throw new IllegalStateException("Anio fuera de Rango");
		}
	}
	
	public void siguienteMes(){
		
		mes++;
		
		if(!esFechaValida()){
			
			if(mes == 2 && esBisiesto() && dia > 29){
				
				dia = 29;
				
			}else{
			
				if(mes == 2 && !esBisiesto() && dia > 28){
				
					dia = 28;
				
				}
			}
			if((mes == 4 || mes == 6 || mes == 9 || mes == 11) && dia == 31){
			
				dia =30;
			}
			else{
				if(!esFechaValida()){
					mes=1;
					anio++;
				}
			}
			
		}
		if(anio>9999){
			
			throw new IllegalStateException("Anio fuera de Rango");
		}
		
	}
	
	public void anteriorMes(){
		
		mes--;
		
		if(!esFechaValida()){
			
			if(mes == 2 && esBisiesto() && dia > 29){
				
				dia = 29;
				
			}else{
			
				if(mes == 2 && !esBisiesto() && dia > 28){
				
					dia = 28;
				
				}
			}
			if((mes == 4 || mes == 6 || mes == 9 || mes == 11) && dia == 31){
			
				dia =30;
			}
			else{
				if(!esFechaValida()){
					mes=12;
					anio--;
				}
			}
			
		}
		if(anio>9999){
			
			throw new IllegalStateException("Anio fuera de Rango");
		}
	}

	public void siguienteAnio(){
		
		anio++;
		
		if(!esFechaValida()){
			
			if(mes == 2 && !esBisiesto() && dia == 29){
				
				dia = 28;
			}
		}
		if(anio>9999){
			
			throw new IllegalStateException("Anio fuera de Rango");
		}
	}
	
	public void anteriorAnio(){
		
		anio--;
		
		if(!esFechaValida()){
			
			if(mes == 2 && !esBisiesto() && dia == 29){
				
				dia = 28;
			}
		}
		if(anio>9999){
			
			throw new IllegalStateException("Anio fuera de Rango");
		}
	}
}
