//Programacion de Aplicaciones Interactivas (PAI)
//Practica 3: Clase Fecha.
//Autor: Gabriel Melian Hernandez
//e-mail: alu0100819786@ull.edu.es


/*-----Implementacion de la clase Principal que hereda de la clase Fecha
donde tendremos nuestro metodo Main para poder comprobar que los metodos implementados
en la clase Fecha funcionan correctamente.-----*/

public class Principal extends Fecha{

	Principal(int dia, int mes, int anio){
		super( dia,  mes,  anio);
	}
	
	public static void main(String[] args) {

		Fecha fechaActual = new Fecha(22, 02, 2017);
		
		Fecha fecha1 = new Fecha (31, 03, 1960);

		Fecha fecha1Bisiesto = new Fecha(21, 03, 1960);
		
		Fecha fecha2 = new Fecha (12, 10, 1492);

		Fecha fecha2Bisiesto = new Fecha(12, 10, 1492);
		
//Ejercicio 1: Mostrar el dia de la semana correspondiente a cada una de las fechas propuestas.

		System.out.println("Entero correspondiente al dia de la semana, comenzando en '0' para el Sabado: " + fecha1.getDiaDeSemana());
		System.out.println(fecha1);
		System.out.println("Entero correspondiente al dia de la semana, comenzando en '0' para el Sabado: " + fecha2.getDiaDeSemana());
		System.out.println(fecha2);

//Ejercicio 2: Mostrar el tiempo transcurrido desde cada una de las fechas propuestas a la fecha actual.

		int dia1Final = fechaActual.getDia() - fecha1.getDia();
		int mes1Final = fechaActual.getMes() - fecha1.getMes();
		int anio1Final = fechaActual.getAnio() - fecha1.getAnio();

		if (mes1Final<0 || (mes1Final==0 && dia1Final<0)){

			anio1Final --;
		}

		System.out.println("Entre la fecha: " + fecha1 + " y la actual, han pasado: " + anio1Final + " años.");

		int dia2Final = fechaActual.getDia() - fecha2.getDia();
		int mes2Final = fechaActual.getMes() - fecha2.getMes();
		int anio2Final = fechaActual.getAnio() - fecha2.getAnio();

		if (mes2Final<0 || (mes2Final==0 && dia2Final<0)){

			anio2Final --;
		}

		System.out.println("Entre la fecha: " + fecha2 + " y la actual, han pasado: " + anio2Final + " años.");

//Ejercicio 3: Mostrar el año bisiesto mas cercano para cada una de las dos fechas propuestas.

		if(fecha1.esBisiesto()){
		
			System.out.println("el año bisiesto mas cercano a la fecha: " + fecha1 + " es: " + fecha1.getAnio());
		}
		else{
			fecha1.anteriorAnio();

			if(fecha1.esBisiesto()){
		
			System.out.println("el año bisiesto mas cercano a la fecha: " + fecha1 + " es: " + fecha1.getAnio());
		}
		else{
			fecha1.anteriorAnio();

			if(fecha1.esBisiesto()){
		
			System.out.println("el año bisiesto mas cercano a la fecha: " + fecha1 + " es: " + fecha1.getAnio());
		}
		else{

			fecha1Bisiesto.siguienteAnio();
			
			System.out.println("el año bisiesto mas cercano a la fecha: " + fecha1 + " es: " + fecha1Bisiesto.getAnio());
		}
		}
		}

		if(fecha2.esBisiesto()){
		
			System.out.println("el año bisiesto mas cercano a la fecha: " + fecha2 + " es: " + fecha2.getAnio());
		}
		else{
			fecha2.anteriorAnio();

			if(fecha2.esBisiesto()){
		
			System.out.println("el año bisiesto mas cercano a la fecha: " + fecha2 + " es: " + fecha2.getAnio());
		}
		else{
			fecha2.anteriorAnio();

			if(fecha2.esBisiesto()){
		
			System.out.println("el año bisiesto mas cercano a la fecha: " + fecha2 + " es: " + fecha2.getAnio());
		}
		else{

			fecha2Bisiesto.siguienteAnio();
			
			System.out.println("el año bisiesto mas cercano a la fecha: " + fecha2 + " es: " + fecha2Bisiesto.getAnio());
		}
		}
		}
	}
}
