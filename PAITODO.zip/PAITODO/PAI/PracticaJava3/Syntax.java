//Programacion de Aplicaciones Interactivas (PAI)
//Practica 3: Ejercicio Miercoles: Clase Syntax.
//Autor: Gabriel Melian Hernandez
//e-mail: alu0100819786@ull.edu.es


import java.io.*;
import java.util.Scanner;

public class Syntax{



	public static void main(String[] args) throws FileNotFoundException{
		
		
		File fichero = new File("HelloWorld.java");
		
		//FileWriter ficheroFinal = null;
	
		FileWriter ficheroFinal = new FileWriter("HelloWorld.html");

		PrintWriter pw = null;

		pw = new PrintWriter(ficheroFinal);
		
		Scanner s = null;

		s = new Scanner(fichero);

			while(s.hasNextLine()){

			String linea = s.nextLine();
			
			if(linea.indexOf('/')){
			
			pw.println("<!-- "+ linea + " -->");
			}
			}

	}		
}
		//System.out.println("Leemos el Fichero");

		
	


/*<!DOCTYPE html>

<html lang="es">

<body>
</body>
</html>
<!--  --> //comentarios*/

