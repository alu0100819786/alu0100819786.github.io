//Practica 2: Introducci�n a Java
//Autor: Gabriel Melian Hernandez
//alu0100819786
public class ClassString { //Creamos la Clase ClassString.

/*Creamos nuestro metodo para contar caracteres, pasamos como argumentos
 * una cadena y el carecter a contar, realizamos la busqueda hasta
 * la priemra aparicion y sumamos al contador, luego continuamos
 * la busqueda desde la ultima aparicion y seguimos incrementando el 
 * contador, hasta que la posicion devuelva -1, que significar� que 
 * no se han encontrado mas caracteres.*/
	public static int contadorCaracteres(String cadena, char caracter){
		
		int posicion;
		int contador=0;
		
		posicion = cadena.indexOf(caracter);
		while (posicion != -1){
			
			contador++;
			posicion = cadena.indexOf(caracter,posicion + 1);
		}
		return contador;
		
	}
	
/*Creamos nuestro m�todo Main, para poder probar que el metodo
 * para contar los caracteres funcciona correctamente*/
	
	public static void main(String[] args){
		
		String texto = new String("Hola Mundo");
		
		char caracterMinus = 'a';
		char caracterMayus = 'A';
		
		System.out.println("En la cadena: " + texto);
		System.out.println("El numero de 'a' es: " + contadorCaracteres(texto, caracterMinus));
		System.out.println("El numero de 'A' es: " + contadorCaracteres(texto, caracterMayus));
	}
	
	
}
