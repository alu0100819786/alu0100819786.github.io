import java.util.ArrayList;
import java.util.Calendar;

public class Edad{
	
	public static void main(String []args){
		
		int k;
		int aux;
		int diaNacimiento;
		int mesNacimiento;
		int añoNacimiento;
		int diaActual;
		int mesActual;
		int añoActual;
		int size = args.length;
		
		ArrayList<Integer> a = new ArrayList<>();
		
		for (k=0; k < size; k++){
			
			a.add(new Integer(args[k]));
			aux= a.get(k);
		}
		
		diaNacimiento = a.get(0);
		mesNacimiento = a.get(1);
		añoNacimiento = a.get(2);
		diaActual = a.get(3);
		mesActual = a.get(4);
		añoActual = a.get(5);
		
		System.out.println("El dia de Nacimiento es: " + diaNacimiento);
		System.out.println("El mes de Nacimiento es: " + mesNacimiento);
		System.out.println("El año de Nacimiento es: " + añoNacimiento);
		System.out.println("El dia actual es: " + diaActual);
		System.out.println("El mes actual es: " + mesActual);
		System.out.println("El año actual es: " + añoActual);
		
		int dia = diaActual - diaNacimiento;
		int mes = mesActual - mesNacimiento;
		int año = añoActual - añoNacimiento;
		
		if (mes<0 || (mes==0 && dia<0)){
			
			año--;
		}
		
		System.out.println("La Persona tiene: " + año + " años.");
	}
}