import java.util.ArrayList;
import java.util.Calendar;

public class Fecha {
	
	private  int dia;
	private  int mes;
	private  int año;
	private int milisegundos;
	
//Constructor que devuelve la fecha Actual.
	public Fecha(){
		
		Calendar fechaActual = Calendar.getInstance();
		dia = fechaActual.get(Calendar.DATE);
		mes = fechaActual.get(Calendar.MONTH);
		año = fechaActual.get(Calendar.YEAR);
	}
//Constructor que devuelve el timepo en milisegundos entre dos fechas
	public Fecha(Fecha fecha){
		int diaFijo = 1;
		int mesFijo = 1;
		int añoFijo = 1970;
		
		dia = fecha.getDia() - diaFijo;
		mes = fecha.getMes() - mesFijo;
		año = fecha.getAño() - añoFijo;
		
		if (mes<0 || (mes==0 && dia<0)){
			
			año--;
		}
		int horas = año*8760;
		milisegundos = horas *3600000;
		
	}
//Constructor que consigue una fecha pasada por parametros.
	public Fecha(int dia, int mes, int año){
		
		this.dia = dia;
		this.mes = mes;
		this.año = año;
	}
	
//-----Setters y Getters-----
//Colecci�n de m�todos set y get para poder acceder a los m�todos
//Con los setters modificamos el atributo, mientras que con get cogemos su valor-----
	
	public void setDia(int d){
		
		dia = d;
	}
	
	public void setMes(int m){
		
		mes = m;
	}
	
	public void setAño(int a){
		
		año = a;
	}
	
	public int getDia(){
		
		return dia;
	}

	public int getMes(){
		
		return mes;
	}

	public int getAño(){
	
		return año;
	}
	
//-----M�todo setFecha, que acude al metodo esFechaValida() para comprobar
//si una fecha introducida es valida y si es valida procede a realizar
//un proceso como un metodo set, mientras que si no es valida, devuelve una excepcion-----
	
	public void setFecha(int d, int m, int a){
		
		if(esFechaValida()){
			
			dia = d;
			mes = m;
			año = a;
		}
		else{
			throw new IllegalArgumentException("dia, mes o a�o, no v�lido");
		}
	}
	
//-----Metodo esBisiesto(), implementacion de un metodo que comprueba
//si el a�o de la fecha introducida es bisiesto o no.-----
	
	private boolean esBisiesto(){
		
		return (año % 4 == 0 && año % 100 != 0 || año % 400 == 0);
	}
	
//-----Metodo esFechaValida(), implementacion de un metodo que comprueba
//si una fecha introducida es valida o no y devuelve "true" (es un metodo booleano)
//si la fecha es valida.----
	
	public boolean esFechaValida(){
		
		boolean diaCorrecto;
		boolean mesCorrecto;
		boolean añoCorrecto;
		
		añoCorrecto = año > 0;
		mesCorrecto = mes >= 1 && mes <= 12;
		
		switch (mes){
		
			case 2:
				if(esBisiesto()){
					diaCorrecto = dia >= 1 && dia <= 29;
				}
				else{
					diaCorrecto = dia >= 1 && dia <= 28;
				}
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				diaCorrecto = dia >= 1 && dia <= 30;
				break;
			default:
				diaCorrecto = dia >=1 && dia <= 31;
		}
		
		return diaCorrecto && mesCorrecto && añoCorrecto;
	}
	
//-----Metodo getDiaDeSemana(), implementacion de un m�todo, que devuelve
// un entero correspondiente al dia de la semana de la fecha que hemos introducido
//comenzando devolviendo un valor de '0' para el Sabado.-----
	
	public int getDiaDeSemana(){
		
		int mesFormula;
		
		if(esBisiesto()){
			if(mes == 10){
				
				mesFormula = 0;
			}
			else{
				if(mes == 5){
					
					mesFormula = 1;
				}
				else{
					if(mes == 2 || mes == 8){
						
						mesFormula = 2;
					}
					else{
						if(mes == 3 || mes == 11){
							
							mesFormula = 3;
						}
						else{
							if(mes == 6){
								
								mesFormula = 4;
							}
							else{
								if(mes == 9 || mes == 12){
									
									mesFormula = 5;
								}
								else{
									
									mesFormula = 6;
								}
							}
						}
					}
				}
			}
		}
		else{
			if(mes == 1 || mes == 10){
				
				mesFormula = 0;
			}
			else{
				if(mes == 5){
					
					mesFormula = 1;
				}
				else{
					if(mes == 8){
						
						mesFormula = 2;
					}
					else{
						if(mes == 2 || mes == 3 || mes == 11 ){
							
							mesFormula = 3;
						}
						else{
							if(mes == 6){
								
								mesFormula = 4;
							}
							else{
								if(mes == 9 || mes == 12){
									
									mesFormula = 5;
								}
								else{
									
									mesFormula = 6;
								}
							}
						}
					}
				}
		}
	}
		return (dia + mesFormula + año%100 + (año/100)%4 + (((año%100)%4)+(año%100)))%7;

	}
	
//-----Metodo toString(), implementacion de un metodo que devuelve por pantalla
//la fecha introducida, en un formato establecido por el programador.-----
	
	public String toString(){
		
		String diaSemana;
		String mesString;
		
		if(getDiaDeSemana() == 0){
			
			diaSemana = "Sabado";
		}
		else{
			if(getDiaDeSemana() == 1){
				
				diaSemana = "Domingo";
			}
			else{
				if(getDiaDeSemana() == 2){
					
					diaSemana = "Lunes";
				}
				else{
					if(getDiaDeSemana() == 3){
						
						diaSemana = "Martes";
					}
					else{
						if(getDiaDeSemana() == 4){
							
							diaSemana = "Miercoles";
						}
						else{
							if(getDiaDeSemana() == 5){
								
								diaSemana = "Jueves";
							}
							else{
								
								diaSemana = "Viernes";
							}
						}
					}
				}
			}
		}
		if(mes == 1){
			
			mesString = "Enero";
		}
		else{
			if(mes == 2){
				
				mesString = "Febrero";
			}
			else{
				if(mes == 3){
					
					mesString = "Marzo";
				}
				else{
					if(mes == 4){
						
						mesString = "Abril";
					}
					else{
						if(mes == 5){
							
							mesString = "Mayo";
						}
						else{
							if(mes == 6){
								
								mesString = "Junio";
							}
							else{
								if(mes == 7){
									
									mesString = "Julio";
								}
								else{
									if(mes == 8){
										
										mesString = "Agosto";
									}
									else{
										if(mes == 9){
											
											mesString = "Septiembre";
										}
										else{
											if(mes == 10){
												
												mesString = "Octubre";
											}
											else{
												if(mes == 11){
													
													mesString = "Noviembre";
												}
												else{
													
													mesString = "Diciembre";
												}
												
											}
										}
									}
								}
								
							}
							
						}
						
					}
				}
				
			}
		}
		
		
		return diaSemana + ", " + String.valueOf(dia) + " de " + mesString + " de " + String.valueOf(año);
	}
	
//-----Implementacion de m�todos para conseguir el dia, mes y a�o, tanto siguientes, como anteriores
//a la fecha que habiamos introducido.(si el a�o es un valor mayor que 9999, 
//los metodos devuelven una excepcion-----

	public void siguienteDia(){
		
		dia++;
		
		if(!esFechaValida()){
			
			dia = 1;
			mes++;
			
			if(!esFechaValida()){
				
				mes = 1;
				año++;
			}
		}
		if(año>9999){
			
			throw new IllegalStateException("A�o fuera de Rango");
		}
	}
	
	public void anteriorDia(){
		
		dia--;
		
		if(!esFechaValida()){
			
			mes--;
			
			if(mes == 4 || mes == 6 || mes == 9 || mes == 11){
				
				dia = 30;
			}
			else{
				if(mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12){
					
					dia = 31;
				}
				else{
					if (esBisiesto()){
						dia=29;
					}
					else{
						dia=28;
					}
				}
				
			}
			if(!esFechaValida()){
				dia = 31;
				mes= 12;
				año--;
			}
		}
		if(año>9999){
			
			throw new IllegalStateException("A�o fuera de Rango");
		}
	}
	
	public void siguienteMes(){
		
		mes++;
		
		if(!esFechaValida()){
			
			if(mes == 2 && esBisiesto() && dia > 29){
				
				dia = 29;
				
			}else{
			
				if(mes == 2 && !esBisiesto() && dia > 28){
				
					dia = 28;
				
				}
			}
			if((mes == 4 || mes == 6 || mes == 9 || mes == 11) && dia == 31){
			
				dia =30;
			}
			else{
				if(!esFechaValida()){
					mes=1;
					año++;
				}
			}
			
		}
		if(año>9999){
			
			throw new IllegalStateException("A�o fuera de Rango");
		}
		
	}
	
	public void anteriorMes(){
		
		mes--;
		
		if(!esFechaValida()){
			
			if(mes == 2 && esBisiesto() && dia > 29){
				
				dia = 29;
				
			}else{
			
				if(mes == 2 && !esBisiesto() && dia > 28){
				
					dia = 28;
				
				}
			}
			if((mes == 4 || mes == 6 || mes == 9 || mes == 11) && dia == 31){
			
				dia =30;
			}
			else{
				if(!esFechaValida()){
					mes=12;
					año--;
				}
			}
			
		}
		if(año>9999){
			
			throw new IllegalStateException("A�o fuera de Rango");
		}
	}

	public void siguienteAño(){
		
		año++;
		
		if(!esFechaValida()){
			
			if(mes == 2 && !esBisiesto() && dia == 29){
				
				dia = 28;
			}
		}
		if(año>9999){
			
			throw new IllegalStateException("A�o fuera de Rango");
		}
	}
	
	public void anteriorAño(){
		
		año--;
		
		if(!esFechaValida()){
			
			if(mes == 2 && !esBisiesto() && dia == 29){
				
				dia = 28;
			}
		}
		if(año>9999){
			
			throw new IllegalStateException("A�o fuera de Rango");
		}
	}
	
//-----Implementacion de un Metodo Main para poder probar nuestros metodos.-----
	
	public static void main(String[] args) {
		
		int k;
		int aux;
		int size = args.length;
		
		ArrayList<Integer> a = new ArrayList<>();
		
		for (k=0; k < size; k++){
			
			a.add(new Integer(args[k]));
			aux= a.get(k);
		}
		Fecha fecha1 = new Fecha(a.get(0), a.get(1), a.get(2));
		System.out.println(fecha1);
		Fecha fecha2 = new Fecha();
		System.out.println(fecha2);
		Fecha fecha3 = new Fecha(1, 1, 1971);
		Fecha fecha4 = new Fecha(fecha3);
		System.out.println("Han pasado: "+ fecha4.milisegundos + " milisegundos");
	}

}
