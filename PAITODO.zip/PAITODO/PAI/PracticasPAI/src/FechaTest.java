//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 3: Clase Fecha.
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es


import static org.junit.Assert.*;

import org.junit.Test;

//-----Implementacion de los test en JUnit para la clase Fecha.-----

public class FechaTest {

//-----Creamos un objeto Fecha a modo de ejemplo para comprobar los metodos.-----

	Fecha fecha1 = new Fecha (20, 2, 2017);
	
//-----Implementacion de los test para comprobar los metodos, todos los test
//se implementan de forma similar y terminan en un "assertEquals" donde se comprueba
//si el resultado que da el metodo es igual al resultado esperado, siendo correcto el test
//cuando esa igual se cumple.-----
	@Test
	public void testSetDia() {

		fecha1.setDia(20);
		
		int resultadoReal = fecha1.getDia();
		
		int resultadoEsperado = 20;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetMes() {
		
		fecha1.setMes(2);
		
		int resultadoReal = fecha1.getMes();
		
		int resultadoEsperado = 2;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetAño() {
		
		fecha1.setAño(2017);
		
		int resultadoReal = fecha1.getAño();
		
		int resultadoEsperado = 2017;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetFecha() {
		
		fecha1.setFecha(20, 2, 2017);
		
		int resultadoRealDia = fecha1.getDia();
		
		int resultadoEsperadoDia = 20;
		
		assertEquals(resultadoRealDia, resultadoEsperadoDia);
		
		int resultadoRealMes = fecha1.getMes();
		
		int resultadoEsperadoMes = 2;
		
		assertEquals(resultadoRealMes, resultadoEsperadoMes);
		
		int resultadoRealAño = fecha1.getAño();
		
		int resultadoEsperadoAño = 2017;
		
		assertEquals(resultadoRealAño, resultadoEsperadoAño);
	}

	@Test
	public void testGetDia() {
		
		int resultadoReal = fecha1.getDia();
		
		int resultadoEsperado = 20;
		
		assertEquals(resultadoReal, resultadoEsperado);
		
	}

	@Test
	public void testGetMes() {
		
		int resultadoReal = fecha1.getMes();
		
		int resultadoEsperado = 2;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetAño() {
		
		int resultadoReal = fecha1.getAño();
		
		int resultadoEsperado = 2017;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testEsFechaValida() {
		
		boolean resultadoReal = fecha1.esFechaValida();
		
		boolean resultadoEsperado = true;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetDiaDeSemana() {
		
		int resultadoReal = fecha1.getDiaDeSemana();
		
		int resultadoEsperado = 2;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testToString() {

		String resultadoReal = fecha1.toString();
		
		String resultadoEsperado = "Lunes, 20 de Febrero de 2017";
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSiguienteDia() {
		
		fecha1.siguienteDia();
		
		int resultadoReal = fecha1.getDia();
		
		int resultadoEsperado = 21;
		
		assertEquals(resultadoReal, resultadoEsperado);
		
		
	}

	@Test
	public void testAnteriorDia() {
		
		fecha1.anteriorDia();
		
		int resultadoReal = fecha1.getDia();
		
		int resultadoEsperado = 19;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSiguienteMes() {
		
		fecha1.siguienteMes();
		
		int resultadoReal = fecha1.getMes();
		
		int resultadoEsperado = 3;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testAnteriorMes() {
		
		fecha1.anteriorMes();
		
		int resultadoReal = fecha1.getMes();
		
		int resultadoEsperado = 1;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSiguienteAño() {
		
		fecha1.siguienteAño();
		
		int resultadoReal = fecha1.getAño();
		
		int resultadoEsperado = 2018;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testAnteriorAño() {
		
		fecha1.anteriorAño();
		
		int resultadoReal = fecha1.getAño();
		
		int resultadoEsperado = 2016;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

}
