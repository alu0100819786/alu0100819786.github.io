//Programación de Aplicaciones Interactivas (PAI)
//Practica 3: Clase Fecha.
//Autor: Gabriel Melián Hernández
//e-mail: alu0100819786@ull.edu.es
import java.io.*;
import java.util.Hashtable;
import java.util.Scanner;
//-----Implementacion de la clase Principal que hereda de la clase Fecha
//donde tendremos nuestro método Main para poder comprobar que los metodos implementados
//en la clase Fecha funcionan correctamente.-----

public class Principal extends ALexico{
	Principal(FileReader entrada){
		super(entrada);
	}
//Metodo main en el que recibimos el fichero de entrada por linea de comandos, lo almacenamos, conseguimos la 
//tabla hash y llamamos al metodo Analizador para que lleve a cabo el proceso de analisis.
	public static void main(String[] args) throws IOException {
		Hashtable<String,String> tablaSimbolos=new Hashtable<String,String>();
		FileReader tabla = new FileReader("TablaSimbolos.txt");
		int k;
		FileReader entrada = null;
		int size = args.length;
		for(k = 0; k < size; k++){
			entrada = new FileReader(args[k]);
		}
		Scanner leer = null;
		leer = new Scanner(tabla);
		while(leer.hasNextLine()){
			String linea = leer.nextLine();
			String[] lineaActual = linea.split(" ");
			int numeroTokens = lineaActual.length;
			int l;
			for(l=0;l<numeroTokens;l++){
				tablaSimbolos.put(lineaActual[l], lineaActual[l+1]);
				l = l+2;
			}
		}
		Analizador(entrada,tablaSimbolos);
		tabla.close();
		leer.close();
	}
}