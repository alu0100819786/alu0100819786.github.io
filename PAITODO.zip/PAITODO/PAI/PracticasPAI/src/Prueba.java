import java.io.*;
import java.util.Hashtable;
import java.util.Scanner;

public class Prueba {

	private FileReader entrada;
	
	public Prueba(){
	}
	
	public Prueba(FileReader entrada){
		
		this.entrada = entrada;
	}
	
	public void setFichero(FileReader fichero){
		
		entrada = fichero;
	}
	
	public FileReader getfichero(){
		
		return entrada;
	}
	
	public static void Analizador(FileReader entrada, Hashtable<String,String> tablaSimbolos) throws IOException{
		
		int j;
		int numeroTokens;
		Scanner s = null;
		FileWriter salida = new FileWriter("salida.txt");
		
		s = new Scanner(entrada);
		int lineaToken = 1;
		
		while(s.hasNextLine()){
		
			String linea = s.nextLine();
			String[] lineaActual = linea.split(" ");
			
			numeroTokens = lineaActual.length;
			
			for(j=0;j<numeroTokens;j++){
				
				String palabra = lineaActual[j];
			
			if(tablaSimbolos.containsKey(palabra)){
				
				salida.write(lineaToken + " " + (linea.indexOf(palabra)+1) + " " + tablaSimbolos.get(palabra) + " " + palabra + "\n");
			}
			else{
				
				char numero = palabra.charAt(0);
				if(Character.isDigit(numero)){
							salida.write(lineaToken + " " + (linea.indexOf(palabra)+1) + " " + "DOUBLE " + palabra + "\n");
				}
				else{
					char letra = palabra.charAt(0);
					if(Character.isLetter(letra)){
						salida.write(lineaToken + " " + (linea.indexOf(palabra)+1) + " " + "ID " + palabra + "\n");
					}
					else{
						char comentario = palabra.charAt(0);
						if(comentario == '/'){
							
						}
						else{
							salida.write(lineaToken + " " + (linea.indexOf(palabra)+1) + " " + palabra + ": TOKEN_ERROR" + "\n");
						}
						
					}
				}
			}	
		}
		lineaToken++;
	}
		salida.write("EOF");
		s.close();
		entrada.close();
		salida.close();
	}
	
	public static void main(String[] args) throws IOException {
		
		Hashtable<String,String> tablaSimbolos=new Hashtable<String,String>();
		
			tablaSimbolos.put("abstract", "KWABSTRACT");
			tablaSimbolos.put("assert", "KWASSERT");
			tablaSimbolos.put("boolean", "KWBOOLEAN");
			tablaSimbolos.put("break", "KWBREAK");
			tablaSimbolos.put("byte", "KWBYTE");
			tablaSimbolos.put("case", "KWCASE");
			tablaSimbolos.put("catch", "KWCATCH");
			tablaSimbolos.put("char", "KWCHAR");
			tablaSimbolos.put("class", "KWCLASS");
			tablaSimbolos.put("const", "KWCONST");
			tablaSimbolos.put("continue", "KWCONTINUE");
			tablaSimbolos.put("default", "KWDEFAULT");
			tablaSimbolos.put("do", "KWDO");
			tablaSimbolos.put("dobule", "KWDOUBLE");
			tablaSimbolos.put("else", "KWELSE");
			tablaSimbolos.put("enum", "KWENUM");
			tablaSimbolos.put("extends", "KWEXTENDS");
			tablaSimbolos.put("final", "KWFINAL");
			tablaSimbolos.put("finally", "KWFINALLY");
			tablaSimbolos.put("float", "KWFLOAT");
			tablaSimbolos.put("for", "KWFOR");
			tablaSimbolos.put("goto", "KWGOTO");
			tablaSimbolos.put("if", "KWIF");
			tablaSimbolos.put("implements", "KWIMPLEMENTS");
			tablaSimbolos.put("import", "KWIMPORT");
			tablaSimbolos.put("instanceof", "KWINSTANCEOF");
			tablaSimbolos.put("int", "KWINT");
			tablaSimbolos.put("interface", "KWINTERFACE");
			tablaSimbolos.put("long", "KWLONG");
			tablaSimbolos.put("native", "KWNATIVE");
			tablaSimbolos.put("new", "KWNEW");
			tablaSimbolos.put("package", "KWPACKAGE");
			tablaSimbolos.put("private", "KWPRIVATE");
			tablaSimbolos.put("protected", "KWPROTECTED");
			tablaSimbolos.put("public", "KWPUBLIC");
			tablaSimbolos.put("return", "KWRETURN");
			tablaSimbolos.put("short", "KWSHORT");
			tablaSimbolos.put("static", "KWSTATIC");
			tablaSimbolos.put("strictfp", "KWSTRICTFP");
			tablaSimbolos.put("super", "KWSUPER");
			tablaSimbolos.put("switch", "KWSWITCH");
			tablaSimbolos.put("synchronized", "KWSYNCHRONIZED");
			tablaSimbolos.put("this", "KWTHIS");
			tablaSimbolos.put("throw", "KWTHROW");
			tablaSimbolos.put("throws", "KWTHROWS");
			tablaSimbolos.put("transient", "KWTRANSIENT");
			tablaSimbolos.put("try", "KWTRY");
			tablaSimbolos.put("void", "KWVOID");
			tablaSimbolos.put("volatile", "KWVOLATILE");
			tablaSimbolos.put("while", "KWWHILE");
			tablaSimbolos.put("(", "OPAR");
			tablaSimbolos.put(")", "CPAR");
			tablaSimbolos.put("{", "OBRACE");
			tablaSimbolos.put("}", "CBRACE");
			tablaSimbolos.put("[", "OCOR");
			tablaSimbolos.put("]", "CCOR");
			tablaSimbolos.put(";", "SEMICOLON");
			tablaSimbolos.put(",", "COMA");
			tablaSimbolos.put(".", "PUNTO");
			tablaSimbolos.put("=", "EQ");
			tablaSimbolos.put("==", "EQEQ");
			tablaSimbolos.put("+", "PL");
			tablaSimbolos.put("+=", "PLEQ");
			tablaSimbolos.put(">", "MAJOR");
			tablaSimbolos.put("<=", "MINEQ");
			tablaSimbolos.put("-", "DIF");
			tablaSimbolos.put("-=", "DIFEQ");
			tablaSimbolos.put("<", "MINOR");
			tablaSimbolos.put(">=", "MAJEQ");
			tablaSimbolos.put("*", "MULT");
			tablaSimbolos.put("*=", "MULTEQ");
			tablaSimbolos.put("!", "EXC");
			tablaSimbolos.put("!=", "EXCEQ");
			tablaSimbolos.put("/", "DIV");
			tablaSimbolos.put("/=", "DIVEQ");
			tablaSimbolos.put("~", "VIR");
			tablaSimbolos.put("&&", "AMPAMP");
			tablaSimbolos.put("&", "AMP");
			tablaSimbolos.put("&=", "AMPEQ");
			tablaSimbolos.put("?", "QUEST");
			tablaSimbolos.put("||", "OR");
			tablaSimbolos.put("|", "SLAV");
			tablaSimbolos.put("|=", "SLAVEQ");
			tablaSimbolos.put(":", "DP");
			tablaSimbolos.put("++", "PLPL");
			tablaSimbolos.put("^", "ELEV");
			tablaSimbolos.put("^=", "ELEVEQ");
			tablaSimbolos.put("--", "DIFDIF");
			tablaSimbolos.put("%", "MOD");
			tablaSimbolos.put("%=", "MODEQ");
			tablaSimbolos.put("<<", "MINMIN");
			tablaSimbolos.put("<<=", "MINMINEQ");
			tablaSimbolos.put(">>=", "MAJMAJEQ");
			tablaSimbolos.put(">>>", "MAJMAJMAJ");
			tablaSimbolos.put(">>>=", "MAJMAJMAJEQ");
			
			int k;
			FileReader entrada = null;
			int size = args.length;
			
			for(k = 0 ; k < size; k++){
				entrada = new FileReader(args[k]);
			}
			
			Analizador(entrada,tablaSimbolos);
	}

}

