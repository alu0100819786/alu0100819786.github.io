//Practica 2: Introducci�n a Java
//Autor: Gabriel Melian Hernandez
//alu0100819786

public class Racional { //Creamos la Clase racional.
	
//Creamos las variables para numerador y denominador.
	
	private int num; 
	private int den;

//Creamos el constructor de la clase
	
	public Racional (int num, int den){
		
		this.num = num;
		this.den = den;
	}
	
/* Creamos el metodo ToString para sacar por pantalla
 * el numero racional que tengamos */

	
	public String toString(){
		
		return String.valueOf(num) + '/' + String.valueOf(den);
		
	}
	
/* Creamos metodo booleano para saber si el numero introducido 
 * tiene denominador distinto de cero y por lo tanto v�lido*/
	
	public static boolean denominador(Racional r1){
		
		return (r1.den!=0);
	}
	
/* Creamos los metodos para las operaciones aritm�ticas de
 * suma, resta, producto y division.
 * Para la suma y la resta usamos los productos cruzados*/

	
	public static Racional suma (Racional r1, Racional r2) {
			
		if(denominador(r1)==true && denominador(r2)==true){
			
			Racional sum = new Racional(r1.num*r2.den+r1.den*r2.num,r1.den*r2.den);
			return sum;
		}
		else{
			Racional error = new Racional(0,0);
			return error;
		
		}
	}
	
	public static Racional resta (Racional r1, Racional r2) {
		
		if(denominador(r1)==true && denominador(r2)==true){
			Racional dif = new Racional(r1.num*r2.den-r1.den*r2.num,r1.den*r2.den);
			return dif;
		}
		else{
			Racional error = new Racional(0,0);
			return error;
		
		}
	} 
	
	public static Racional multiplicar (Racional r1, Racional r2) {
		
		if(denominador(r1)==true && denominador(r2)==true){
			Racional mult = new Racional(r1.num*r2.num, r1.den*r2.den);
			return mult;
	    }
		else{
			Racional error = new Racional(0,0);
			return error;
		
		}
	}
	
	 public static Racional dividir (Racional r1, Racional r2) {
		 
		 if(denominador(r1)==true && denominador(r2)==true){
			 Racional mult = new Racional(r1.num*r2.den, r1.den*r2.num);
			 return mult;
		 }
		 else{
			 Racional error = new Racional(0,0);
			 return error;
		 }
	}
	
	 
/* Creamos un m�todo Main para poder probar las operaciones
 * aritm�ticas que hemos desarollado, usando el constructor
 * para pasarle los numeros racionales que queremos */
	 
	public static void main (String[] args){
		
		Racional r1 = new Racional (3,5);
		Racional r2 = new Racional (2,5);
		
		System.out.println("�R1 tiene denominador distinto de cero?: " + denominador(r1));
		System.out.println("�R2 tiene denominador distinto de cero?: " + denominador(r2));
		System.out.println("El resultado de la suma es: " + suma(r1, r2));
		System.out.println("El resultado de la resta es: " + resta(r1, r2));
		System.out.println("El resultado del producto es: " + multiplicar(r1, r2));
		System.out.println("El resultado de la division es: " + dividir(r1, r2));
	}
}
