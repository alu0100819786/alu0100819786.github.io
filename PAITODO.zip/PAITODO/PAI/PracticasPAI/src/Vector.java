import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Vector {

	public static void main(String []args) throws FileNotFoundException{
		
		File fichero = new File("datos.txt");
		Scanner s = null;
		System.out.println("Leemos el Fichero");
		
		s = new Scanner(fichero);
		int maximo = -99999;
		int minimo = 99999;
		int diferencia;
		
		while (s.hasNextLine()){
			
			String linea = s.nextLine();
			int aux = Integer.parseInt(linea);
			
			if (aux > maximo){
				maximo= aux;
			}
			if (aux < minimo){
				minimo = aux;
			}
		}
		
		diferencia = maximo - minimo;
		
		System.out.println("El M�ximo es: " + maximo);
		System.out.println("El Minimo es: " + minimo);
		System.out.println("Diferencia: " + diferencia);
		
	
	}
}
