//Programación de Aplicaciones Interactivas (PAI)
//Practica 5: Game Of Life
//Autor: Gabriel Melián Hernández
//e-mail: alu0100819786@ull.edu.es
import static org.junit.Assert.*;
import java.io.*;
import org.junit.Test;
//Declaracion de la clase GameOfLifeTest que albergará los test para comprobar el correcto funcionamiento
//de los metodos principales de la clase GameOfLife.
public class GameOfLifeTest {
	//Creamos un objeto de prueba.
	GameOfLife prueba = new GameOfLife();
//Coleccion de Test, para comprobar que funcionan correctamente los seters y getters.
	@Test
	public void testSetFilas() {
		
		prueba.setFilas(10);
		int resultadoReal = prueba.getFilas();
		
		int resultadoEsperado = 10;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetColumnas() {
		prueba.setColumnas(10);
		int resultadoReal = prueba.getColumnas();
		
		int resultadoEsperado = 10;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetIteraciones() {
		prueba.setIteraciones(40);
		int resultadoReal = prueba.getIteraciones();
		
		int resultadoEsperado = 40;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetEntrada() throws FileNotFoundException{
		FileReader entrada = new FileReader("datos.txt");
		prueba.setEntrada(entrada);
		FileReader resultadoReal = prueba.getEntrada();
		
		FileReader resultadoEsperado = entrada;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testSetSalida() throws IOException {
		FileWriter salida = new FileWriter("salida.txt");
		prueba.setSalida(salida);
		FileWriter resultadoReal = prueba.getSalida();
		
		FileWriter resultadoEsperado = salida;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetFilas() {
		prueba.setFilas(10);
		int resultadoReal = prueba.getFilas();
		
		int resultadoEsperado = 10;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetColumnas() {
		prueba.setColumnas(10);
		int resultadoReal = prueba.getColumnas();
		
		int resultadoEsperado = 10;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetIteraciones() {
		prueba.setIteraciones(40);
		int resultadoReal = prueba.getIteraciones();
		
		int resultadoEsperado = 40;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetEntrada() throws FileNotFoundException {
		FileReader entrada = new FileReader("datos.txt");
		prueba.setEntrada(entrada);
		FileReader resultadoReal = prueba.getEntrada();
		
		FileReader resultadoEsperado = entrada;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

	@Test
	public void testGetSalida() throws IOException {
		FileWriter salida = new FileWriter("salida.txt");
		prueba.setSalida(salida);
		FileWriter resultadoReal = prueba.getSalida();
		
		FileWriter resultadoEsperado = salida;
		
		assertEquals(resultadoReal, resultadoEsperado);
	}

}
