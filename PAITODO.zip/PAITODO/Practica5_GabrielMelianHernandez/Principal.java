//Programación de Aplicaciones Interactivas (PAI)
//Practica 5: Game Of Life
//Autor: Gabriel Melián Hernández
//e-mail: alu0100819786@ull.edu.es
import java.io.*;
import java.util.ArrayList;
//Implementación de la clase principal que hereda de la clase GameOfLife donde tendremos el método main,
//Para llevar a cabo las comprobaciones de que el programa funciona correctamente.
public class Principal extends GameOfLife{
	Principal(){
		super();
	}
//Metodo main el cual recibe argumentos por linea de comandos, crea un nuevo objeto GameOfLife y llama
//al método setGame para comenzar la configuracion del juego y su ejecución.
	public static void main(String[] args) throws IOException {
		int k;
		String aux;
		FileReader entrada = null;
		FileWriter salida = null;
		int size = args.length;
		ArrayList<String> a = new ArrayList<>();
			for (k=0; k < size; k++){
			
			a.add(new String(args[k]));
			aux= a.get(k);
		}
		int iteraciones = Integer.valueOf(a.get(0));
		int filas = Integer.valueOf(a.get(1));
		int columnas = Integer.valueOf(a.get(2));
		entrada = new FileReader(a.get(3));
		salida = new FileWriter(a.get(4));
		setIteraciones(iteraciones);
		setFilas(filas);
		setColumnas(columnas);
		setEntrada(entrada);
		setSalida(salida);
		GameOfLife prueba=new GameOfLife();
		prueba.setGame(entrada,salida,iteraciones,filas,columnas);
		
		entrada.close();
		salida.close();
	}
}