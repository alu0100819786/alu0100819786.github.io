//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 8: Graficos
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.awt.*;
import javax.swing.JFrame;

public class Cara extends JFrame{

	public Cara(){
		setTitle("Dibujar Cara");
	}
	public void paint (Graphics g){
		super.paint(g);
	      //Dibujo el contorno de la cara
	      g.setColor(Color.BLACK);
	      g.drawOval(105, 70, 100, 100);
	      
	      //Dibujo de los ojos
	      g.setColor(Color.BLUE);
	      g.fillOval(120, 100, 20, 20);
	      g.fillOval(170, 100, 20, 20);
	      
	      //Dibujo de la boca
	      g.setColor(Color.RED);
	      g.drawLine(135, 140, 175, 140);
	    }
	public static void main(String[] args) {
		Cara frame = new Cara();
	    frame.setLocationRelativeTo(null);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(300, 300);
	    frame.setVisible(true);
	}
}
