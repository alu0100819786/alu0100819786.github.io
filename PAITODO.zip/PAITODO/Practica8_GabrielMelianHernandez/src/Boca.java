import java.awt.*;

public class Boca extends Cara{
	public Boca(){
	}
	public void DibujarBoca(Graphics g){
		Cara n = new Cara();
		g.setColor(Color.RED);
		g.drawLine(n.getX()+30, n.getY()+70, n.getX()+70, n.getY()+70);
	}
}
