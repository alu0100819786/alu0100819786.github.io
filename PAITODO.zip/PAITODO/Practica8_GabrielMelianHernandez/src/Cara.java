//Programación de Aplicaciones Interactivas (PAI)
//Practica 8: Graficos
//Autor: Gabriel Melián Hernández
//e-mail: alu0100819786@ull.edu.es
import java.awt.*;
import javax.swing.JFrame;

public class Cara extends JFrame{

	private static int x;
	private static int y;
	
	public static void setX(int puntoX){
		x=puntoX;
	}
	public int getX(){
		return x;
	}
	public static void setY(int puntoY){
		y=puntoY;
	}
	public int getY(){
		return y;
	}
	public Cara(){
		setTitle("Dibujar Cara");
	}
	public void paint (Graphics g){
		super.paint(g);
	    //Dibujo el contorno de la cara
		double radio = 0.17*getWidth();
	    double perimetro = 2*radio;
	    double pojo = 0.20*perimetro;
		Contorno contorno = new Contorno();
	    contorno.DibujarContorno(g,perimetro);
	    //Dibujo de los ojos
	    OjoIzquierdo ojoIzq = new OjoIzquierdo();
	    OjoDerecho ojoDcho = new OjoDerecho();
	    ojoIzq.DibujarOjoIzquierdo(g,pojo);
	    ojoDcho.DibujarOjoDerecho(g,pojo);
	    //Dibujo de la boca
	    Boca boca = new Boca();
	    boca.DibujarBoca(g);
	    }
	
}
