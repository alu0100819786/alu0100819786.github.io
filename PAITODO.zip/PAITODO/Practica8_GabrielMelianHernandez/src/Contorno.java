import java.awt.*;

public class Contorno extends Cara{
	public Contorno(){
	}
	public void DibujarContorno(Graphics g,double perimetro){
		Cara n = new Cara();
		g.setColor(Color.BLACK);
	    g.drawOval(n.getX(), n.getY(),(int)perimetro,(int)perimetro);
	}
	
}
