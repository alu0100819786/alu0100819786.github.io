//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 8: Graficos
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.awt.*;
import javax.swing.JFrame;

public class Cuadratica extends JFrame {
    public Cuadratica() {
    	setTitle("Dibujar Funcion Cuadratica");
    }
    public void paint( Graphics g ) {
    	//y=c*x2 + c*x + c
        super.paint(g);
        g.setColor(Color.RED);
        g.drawLine(0, this.getHeight()/2, this.getWidth(), this.getHeight()/2);//Dibujamos el eje de las X
        g.drawLine(this.getWidth()/2, 0,this.getWidth()/2 , this.getHeight());//Dibujamos el eje de las Y
        double x1 = -100;//Limite en el que evaluamos X hacia el negativo
        double x2 = 100;//Limite en el que evaluamos X hacia el positivo
        double cons = 0;//Constante.
        double x1mult = 0;//Multiplicador de la x
        double x2mult = 1; //multiplicador de la x2
        for(double i=x1;i<x2;i++){
        	double y = ((double)Math.pow(i,2)*x2mult)+i*x1mult+cons;//Conseguimos el valor de y para cada valor de x
            double xp = i+1;
            double yp = ((double)Math.pow(xp,2)*x2mult)+xp*x1mult+cons;//calculamos la siguietne coordenada, para poder trazar la linea
            g.setColor(Color.BLACK);
            g.drawLine((int)coord_x(i), (int)coord_y(y), (int)coord_x(xp), (int)coord_y(yp));
    }
}
//Metodo para regresar la coordenada real para el eje de las X ajustada a nuestros ejes
//debido a que por defecto el punto (0,0) es la esquina superior izquierda.
private double coord_x(double x){
	double real_x = x+this.getWidth()/2;
	return real_x;
}
//Metodo para regresar la coordenada real para el eje de las Y ajustada a nuestros ejes
//debido a que por defecto el punto (0,0) es la esquina superior izquierda.
private double coord_y(double y){
	double real_y = -y+this.getHeight()/2;
	return real_y;
}
    public static void main(String args[]) {
    	Cuadratica frame = new Cuadratica();
    	frame.setLocationRelativeTo(null);
 	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 	    frame.setSize(600, 600);
 	    frame.setVisible(true);

    }
}