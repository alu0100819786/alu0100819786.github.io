//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 8: Graficos
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
public class DibujaFuncionCuadrada extends Funciones{
	
	public DibujaFuncionCuadrada() {
    	setTitle("Dibujar Funcion");
    }
	public double f(double i, double x2mult, double x1mult, double cons){
		
		double y = ((double)Math.pow(i,2)*x2mult)+i*x1mult+cons;
		return y;
	}
	public double fp(double xp, double x2mult, double x1mult, double cons){
		double y = ((double)Math.pow(xp,2)*x2mult)+xp*x1mult+cons;
		return y;
	}
}
