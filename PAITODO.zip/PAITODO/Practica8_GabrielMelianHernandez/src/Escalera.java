//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 8: Graficos
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.awt.*;
import javax.swing.JFrame;

public class Escalera extends JFrame{

	public Escalera(){
		setTitle("Dibujar Escalera");
	}
	public void paint (Graphics g){
		super.paint(g);
		  //Dibujamos el primer escalon de la escalera.
	      g.setColor(Color.BLACK);
	      g.drawRect(10, 40, 20, 10);
	      int pos = 40;
	      int largo = 20;
	      int i;
	      //Hacemos un bucle que vaya dibujando los demas escalones de la escalera, aumentando su tama�o.
	      for(i=0; i<=10; i++){
	    	  pos=pos+10;
	    	  largo=largo+10;
	    	  g.drawRect(10,pos,largo,10);
	      } 
	    }
	public static void main(String[] args) {
		Escalera frame = new Escalera();
	    frame.setLocationRelativeTo(null);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(200, 200);
	    frame.setVisible(true);
	}
}
