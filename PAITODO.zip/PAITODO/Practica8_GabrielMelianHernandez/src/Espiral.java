//Programaci�n de Aplicaciones Interactivas (PAI)
//Practica 8: Graficos
//Autor: Gabriel Meli�n Hern�ndez
//e-mail: alu0100819786@ull.edu.es
import java.awt.*;
import javax.swing.JFrame;

public class Espiral extends JFrame{
	
	public Espiral(){
		setTitle("Dibujar Espiral");
	}
	public void paint (Graphics g){
		super.paint(g);
	      //Dibujamos la primera linea de la espiral
	      g.setColor(Color.BLACK);
	      g.drawLine(10, 40, 160, 40);
	      int x1 = 10;
	      int y1 = 40;
	      int x2 = 160;
	      int y2 = 40;
	      int inicio = 40;
	      int i;
	      //Bucle for que dibuja las siguientes lineas de la espiral hasta rellenarse.
	      for(i=0;i<=5;i++){
	    	  x1=x2;
	    	  y2=x2-10;
	    	  g.drawLine(x1, y1, x2, y2);
	    	  y1=y2;
	    	  x2=160-y2;
	    	  g.drawLine(x1, y1, x2, y2);
	    	  x1=x2;
	    	  inicio = inicio +10;
	    	  y2=inicio;
	    	  g.drawLine(x1, y1, x2, y2);
	    	  x2=y1;
	    	  y1=y2;
	    	  g.drawLine(x1, y1, x2, y2);
	      }
	}
	public static void main(String[] args) {
		Espiral frame = new Espiral();
	    frame.setLocationRelativeTo(null);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(170, 170);
	    frame.setVisible(true);
	}
}
