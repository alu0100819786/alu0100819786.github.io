import java.awt.*;

public class OjoDerecho extends Cara{
	public OjoDerecho(){
	}
	public void DibujarOjoDerecho(Graphics g,double pojo){
		Cara n = new Cara();
		g.setColor(Color.BLUE);
		g.fillOval(n.getX()+65, n.getY()+30, (int)pojo, (int)pojo);
	}

}
