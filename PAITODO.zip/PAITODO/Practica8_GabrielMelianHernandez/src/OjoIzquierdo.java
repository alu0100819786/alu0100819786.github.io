import java.awt.*;

public class OjoIzquierdo extends Cara{
	public OjoIzquierdo(){
	}
	public void DibujarOjoIzquierdo(Graphics g,double pojo){
		Cara n = new Cara();
		g.setColor(Color.BLUE);
	    g.fillOval(n.getX()+15, n.getY()+30, (int)pojo, (int)pojo);
	}

}
