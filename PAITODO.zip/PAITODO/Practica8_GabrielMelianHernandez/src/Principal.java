import java.util.ArrayList;
import javax.swing.JFrame;

public class Principal extends Cara{
	Principal(){
		super();
	}

	public static void main(String[] args) {
		Cara frame = new Cara();
		int k;
		int aux;
		int size = args.length;
		ArrayList<Integer> a = new ArrayList<>();
		for (k=0; k < size; k++){
			
			a.add(new Integer(args[k]));
			aux= a.get(k);
		}
		setX(a.get(0));
		setY(a.get(1));
	    frame.setLocationRelativeTo(null);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(300, 300);
	    frame.setVisible(true);
	}
}
